<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// ===============================
// DEFAULT LANDING
// ===============================
$routes->get('/', 'Auth::login');

// ===============================
// AUTH ROUTES
// ===============================
// ==========================
// ✅ AUTH ROUTES (MATCHED TO YOUR CONTROLLER)
// ==========================

$routes->get('auth/login', 'Auth::login');        // show login
$routes->post('auth/process', 'Auth::process');  // login process ✅ FIXED

$routes->get('auth/register', 'Auth::register'); // show register
$routes->post('auth/save', 'Auth::save');        // save registered user

$routes->get('auth/logout', 'Auth::logout');     // logout



// ===============================
// ADMIN ROUTES (PROTECTED)
// ===============================
$routes->group('admin', [
    'namespace' => 'App\Controllers\Admin',
    'filter'    => 'auth'
], function ($routes) {

    // -------------------------------
    // DASHBOARD
    // -------------------------------
    

    $routes->get('dashboard', 'Dashboard::index');

    // -------------------- DISBURSEMENT --------------------
    $routes->get('disbursement', 'Disbursement::index');
    $routes->get('disbursement_create', 'Disbursement::create');
    $routes->post('disbursement/store', 'Disbursement::store');
    $routes->get('disbursement/edit/(:num)', 'Disbursement::edit/$1');
    $routes->post('disbursement/update/(:num)', 'Disbursement::update/$1');
    $routes->get('disbursement/delete/(:num)', 'Disbursement::delete/$1');
    $routes->get('disbursement/toggleInOut/(:num)', 'Disbursement::toggleInOut/$1');
    $routes->get('admin/disbursement/viewFile/(:any)', 'Admin\Disbursement::viewFile/$1');


    // -------------------- VALIDATION --------------------
    $routes->get('validation', 'Validation::index');
    $routes->get('validation_create', 'Validation::create');
    $routes->post('validation/store', 'Validation::store');
    $routes->get('validation/delete/(:num)', 'Validation::delete/$1');
    $routes->get('validation/toggleInOut/(:num)', 'Validation::toggleInOut/$1');

    // -------------------- LIQUIDATION --------------------
    $routes->get('liquidations', 'Liquidations::index');
    $routes->get('liquidations_create', 'Liquidations::create');
    $routes->post('liquidations/store', 'Liquidations::store');
    $routes->get('liquidations/edit/(:num)', 'Liquidations::edit/$1');
    $routes->post('liquidations/update/(:num)', 'Liquidations::update/$1');
    $routes->get('liquidations/delete/(:num)', 'Liquidations::delete/$1');
    $routes->get('liquidations/toggleInOut/(:num)', 'Liquidations::toggleInOut/$1');

    // -------------------- BILLING --------------------
    $routes->get('billing', 'Billing::index');
    $routes->get('billing_create', 'Billing::create');
    $routes->post('billing/store', 'Billing::store');
    $routes->get('billing_edit/(:num)', 'Billing::edit/$1');  
    $routes->post('billing/update/(:num)', 'Billing::update/$1');
    $routes->get('billing/delete/(:num)', 'Billing::delete/$1');
    $routes->get('billing/toggleInOut/(:num)', 'Billing::toggleInOut/$1');

    // ================= USER MANAGEMENT (NO S) =================
    $routes->get('user', 'User::index');                 // SHOW USERS
    $routes->get('user/create', 'User::create');         // ADD FORM
    $routes->post('user/store', 'User::store');          // SAVE
    $routes->get('user/edit/(:num)', 'User::edit/$1');   // EDIT FORM
    $routes->post('user/update/(:num)', 'User::update/$1');
    $routes->get('user/delete/(:num)', 'User::delete/$1');


// This should be **outside the admin group**, accessible publicly
$routes->get('uploads/(:segment)', 'Admin\Validation::viewFile/$1');

    // -------------------- ANALYTICS --------------------
    $routes->get('analytics/data', 'Analytics::data');
});
$routes->get('user/dashboard', 'User::dashboard');
// User routes
$routes->group('user', ['namespace' => 'App\Controllers'], function($routes) {
    $routes->get('dashboard', 'User::dashboard');
    $routes->get('profile', 'User::profile');
    $routes->get('logout', 'User::logout');
});

// User routes
$routes->group('user', ['namespace' => 'App\Controllers'], function($routes) {

    // Dashboard
    $routes->get('dashboard', 'User::dashboard');

    // Validation files
    $routes->get('validation_list', 'User::validationList');   // List for user
    $routes->get('validation/create', 'User::createValidation'); // Upload new file
    $routes->post('validation/store', 'User::storeValidation');  // Store uploaded file
    $routes->get('validation/edit/(:num)', 'User::editValidation/$1'); // Edit own file
    $routes->post('validation/update/(:num)', 'User::updateValidation/$1'); 
    $routes->get('validation/delete/(:num)', 'User::deleteValidation/$1');

    // Liquidation files
    $routes->get('liquidation_list', 'User::liquidationList');
    $routes->get('liquidation/create', 'User::createLiquidation');
    $routes->post('liquidation/store', 'User::storeLiquidation');
    $routes->get('liquidation/edit/(:num)', 'User::editLiquidation/$1');
    $routes->post('liquidation/update/(:num)', 'User::updateLiquidation/$1');
    $routes->get('liquidation/delete/(:num)', 'User::deleteLiquidation/$1');

    // Disbursement files
    $routes->get('disbursement_list', 'User::disbursementList');
    $routes->get('disbursement/create', 'User::createDisbursement');
    $routes->post('disbursement/store', 'User::storeDisbursement');
    $routes->get('disbursement/edit/(:num)', 'User::editDisbursement/$1');
    $routes->post('disbursement/update/(:num)', 'User::updateDisbursement/$1');
    $routes->get('disbursement/delete/(:num)', 'User::deleteDisbursement/$1');

    // Billing files
    $routes->get('billing_list', 'User::billingList');
    $routes->get('billing/create', 'User::createBilling');
    $routes->post('billing/store', 'User::storeBilling');
    $routes->get('billing/edit/(:num)', 'User::editBilling/$1');
    $routes->post('billing/update/(:num)', 'User::updateBilling/$1');
    $routes->get('billing/delete/(:num)', 'User::deleteBilling/$1');

    // Profile
    $routes->get('profile', 'User::profile');
    $routes->post('profile/update', 'User::updateProfile');
});
$routes->group('user', ['namespace' => 'App\Controllers'], function($routes) {

    // Dashboard
    $routes->get('dashboard', 'User::dashboard');

    // Validation
    $routes->get('validation_list', 'User::validationList');
    $routes->post('validation/store', 'User::storeValidation');

    // Liquidation
    $routes->get('liquidation_list', 'User::liquidationList');
    $routes->post('liquidation/store', 'User::storeLiquidation');

    // Disbursement
    $routes->get('disbursement_list', 'User::disbursementList');
    $routes->post('disbursement/store', 'User::storeDisbursement');

    // Billing
    $routes->get('billing_list', 'User::billingList');
    $routes->post('billing/store', 'User::storeBilling');

    // Profile
    $routes->get('profile', 'User::profile');
    $routes->post('profile/update', 'User::updateProfile');

});
$routes->group('user', ['namespace' => 'App\Controllers'], function($routes) {

    $routes->get('dashboard', 'User::dashboard');

    // Validation
    $routes->get('validation_list', 'User::validationList');
    $routes->post('validation/store', 'User::storeValidation');
    $routes->get('validation/download/(:segment)', 'User::downloadValidation/$1');

    // Liquidation
    $routes->get('liquidation_list', 'User::liquidationList');
    $routes->post('liquidation/store', 'User::storeLiquidation');
    $routes->get('liquidation/download/(:segment)', 'User::downloadLiquidation/$1');

    // Disbursement
    $routes->get('disbursement_list', 'User::disbursementList');
    $routes->post('disbursement/store', 'User::storeDisbursement');
    $routes->get('disbursement/download/(:segment)', 'User::downloadDisbursement/$1');

    // Billing
    $routes->get('billing_list', 'User::billingList');
    $routes->post('billing/store', 'User::storeBilling');
    $routes->get('billing/download/(:segment)', 'User::downloadBilling/$1');

    // Profile
    $routes->get('profile', 'User::profile');
});
$routes->get('user/validation/view/(:segment)', 'User::viewFile/$1');
// User Validation Routes
$routes->get('user/validationList', 'User::validationList');
$routes->get('user/validation_add', 'User::addValidation');       // <-- Add this
$routes->post('user/storeValidation', 'User::storeValidation'); // <-- Add this
$routes->get('user/toggleInOut/(:num)', 'User::toggleInOut/$1');
$routes->get('user/edit/(:num)', 'User::edit/$1');
$routes->post('user/update/(:num)', 'User::update/$1');
$routes->get('user/delete/(:num)', 'User::delete/$1');

// Default route
$routes->get('/', 'SuperAdminController::dashboard');  // opens Superadmin dashboard by default

// Admin login/dashboard
$routes->get('admin', 'AdminController::dashboard');
$routes->get('admin/login', 'AdminController::login');

$routes->get('superadmin', 'SuperAdminController::dashboard');

$routes->get('superadmin/create_user', 'SuperAdminController::createUser');
$routes->post('superadmin/store_user', 'SuperAdminController::storeUser');

$routes->get('superadmin', 'SuperAdminController::dashboard');
$routes->get('superadmin/create_user', 'SuperAdminController::createUser');
$routes->post('superadmin/store_user', 'SuperAdminController::storeUser');
$routes->get('superadmin/edit_user/(:num)', 'SuperAdminController::editUser/$1');
$routes->post('superadmin/update_user/(:num)', 'SuperAdminController::updateUser/$1');
$routes->get('superadmin/delete_user/(:num)', 'SuperAdminController::deleteUser/$1');
// SuperAdmin Dashboard
$routes->get('superadmin', 'SuperAdminController::dashboard');
$routes->get('superadmin/dashboard', 'SuperAdminController::dashboard');

// SuperAdmin User Management
$routes->get('superadmin/users', 'SuperAdminController::users');               // list users
$routes->get('superadmin/users/create', 'SuperAdminController::createUser');   // show create form
$routes->post('superadmin/users/store', 'SuperAdminController::storeUser');    // store new user
$routes->get('superadmin/users/edit/(:num)', 'SuperAdminController::editUser/$1');  // edit form
$routes->post('superadmin/users/update/(:num)', 'SuperAdminController::updateUser/$1'); // update
$routes->get('superadmin/users/delete/(:num)', 'SuperAdminController::deleteUser/$1'); // delete

// Admin Validation Routes
$routes->get('admin/validation', 'Admin\ValidationController::index');             // list validations
$routes->get('admin/validation/edit/(:num)', 'Admin\ValidationController::edit/$1'); // edit form
$routes->post('admin/validation/update/(:num)', 'Admin\ValidationController::update/$1');

$routes->group('superadmin', ['filter' => 'auth'], function($routes) {

    // Dashboard
    $routes->get('dashboard', 'SuperAdmin::dashboard');

    // User Management (Admins only)
    $routes->get('users', 'SuperAdmin::users');
    $routes->get('user/create', 'SuperAdmin::createUser');
    $routes->post('user/store', 'SuperAdmin::storeUser');
    $routes->get('users/edit/(:num)', 'SuperAdmin::editUser/$1');
    $routes->post('users/update/(:num)', 'SuperAdmin::updateUser/$1');
    $routes->get('users/delete/(:num)', 'SuperAdmin::deleteUser/$1');

    // Monitoring Files (All types)
    $routes->get('files', 'SuperAdmin::files');

    // File Categories
    $routes->get('validation', 'SuperAdmin::validationFiles');
    $routes->get('billing', 'SuperAdmin::billingFiles');
    $routes->get('disbursement', 'SuperAdmin::disbursementFiles');
    $routes->get('liquidation', 'SuperAdmin::liquidationFiles');

});