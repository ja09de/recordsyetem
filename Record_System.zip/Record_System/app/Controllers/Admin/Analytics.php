<?php
namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\DisbursementModel;
use App\Models\LiquidationModel;
use App\Models\ValidationModel;
use App\Models\BillingModel;

class Analytics extends BaseController
{
    public function data()
    {
        $disbursementModel = new DisbursementModel();
        $liquidationModel  = new LiquidationModel();
        $validationModel   = new ValidationModel();
        $billingModel      = new BillingModel();

        // Prepare response for dashboard
        $response = [
            'in_out' => [
                'labels' => ['Disbursement','Liquidation','Validation','Billing'],
                'in'  => [
                    $disbursementModel->where('in_status', 1)->countAllResults(),
                    $liquidationModel->where('in_status', 1)->countAllResults(),
                    $validationModel->where('in_status', 1)->countAllResults(),
                    $billingModel->where('status', 'Pending')->countAllResults() // Billing pending = "In"
                ],
                'out' => [
                    $disbursementModel->where('in_status', 0)->countAllResults(),
                    $liquidationModel->where('in_status', 0)->countAllResults(),
                    $validationModel->where('in_status', 0)->countAllResults(),
                    $billingModel->where('status', 'Paid')->countAllResults() // Billing paid = "Out"
                ]
            ],
            'files' => [
                'total' => [
                    'Disbursement' => $disbursementModel->where('file IS NOT NULL', null, false)->countAllResults(),
                    'Liquidation'  => $liquidationModel->where('file IS NOT NULL', null, false)->countAllResults(),
                    'Validation'   => $validationModel->where('file IS NOT NULL', null, false)->countAllResults(),
                    'Billing'      => $billingModel->where('file IS NOT NULL', null, false)->countAllResults()
                ]
            ]
        ];

        return $this->response->setJSON($response);
    }
}
