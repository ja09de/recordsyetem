<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\BillingModel;

class Billing extends BaseController
{
    public function index()
    {
        $model = new BillingModel();
        return view('admin/billing', [
            'title' => 'Billing',
            'billings' => $model->orderBy('id', 'DESC')->findAll()
        ]);
    }

    public function create()
    {
        return view('admin/billing_create', [
            'title' => 'Add Billing File'
        ]);
    }

    public function store()
    {
        $file = $this->request->getFile('file');

        if (!$file || !$file->isValid()) {
            return redirect()->back()->with('error', 'No file uploaded or invalid file.');
        }

        $newName = $file->getRandomName();
        $file->move('uploads/', $newName); // consistent path

        $recordName = $this->request->getPost('record_name');
        if (!$recordName) {
            return redirect()->back()->with('error', 'Record Name is required.');
        }

        $model = new BillingModel();
        $model->save([
            'record_name' => $recordName,
            'file'        => $newName,
            'in_status'   => 0,
            'uploaded_at' => date('Y-m-d H:i:s') // Make sure column exists in DB
        ]);

        return redirect()->to(site_url('admin/billing'))->with('success', 'File uploaded successfully.');
    }

    public function edit($id)
    {
        $model = new BillingModel();
        $data['billing'] = $model->find($id);

        if (!$data['billing']) {
            return redirect()->to(site_url('admin/billing'))->with('error', 'Record not found.');
        }

        $data['title'] = 'Edit Billing Record';
        return view('admin/billing_edit', $data);
    }

    public function update($id)
    {
        $model = new BillingModel();
        $billing = $model->find($id);

        if (!$billing) {
            return redirect()->to(site_url('admin/billing'))->with('error', 'Record not found.');
        }

        $recordName = $this->request->getPost('record_name');
        if (!$recordName) {
            return redirect()->back()->with('error', 'Record Name is required.');
        }

        $data = ['record_name' => $recordName];

        // Handle file upload if a new file is uploaded
        $file = $this->request->getFile('file');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            $newName = $file->getRandomName();
            $file->move('uploads/', $newName);

            // Delete old file
            if (file_exists('uploads/'.$billing['file'])) {
                unlink('uploads/'.$billing['file']);
            }

            $data['file'] = $newName;
        }

        $model->update($id, $data);

        return redirect()->to(site_url('admin/billing'))->with('success', 'Record updated successfully.');
    }

    public function toggleInOut($id)
    {
        $model = new BillingModel();
        $record = $model->find($id);

        if ($record) {
            $model->update($id, [
                'in_status' => $record['in_status'] ? 0 : 1
            ]);
        }

        return redirect()->back()->with('success', 'Status updated!');
    }

    public function delete($id)
    {
        $model = new BillingModel();
        $record = $model->find($id);

        if ($record && file_exists('uploads/'.$record['file'])) {
            unlink('uploads/'.$record['file']);
        }

        $model->delete($id);

        return redirect()->back()->with('success', 'Billing file deleted!');
    }
}
