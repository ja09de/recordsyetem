<?php

namespace App\Controllers\Admin;
use App\Controllers\BaseController;
use App\Models\ValidationModel;
use App\Models\LiquidationModel;
use App\Models\DisbursementModel;
use App\Models\BillingModel;

class Dashboard extends BaseController
{
    public function index()
    {
        $today = date('Y-m-d');

        // Load models
        $validationModel   = new ValidationModel();
        $liquidationModel  = new LiquidationModel();
        $disbursementModel = new DisbursementModel();
        $billingModel      = new BillingModel();

        // --- Counts IN/OUT ---
        $validation_in  = $validationModel->where('in_status', 1)
            ->where('uploaded_at >=', "$today 00:00:00")
            ->where('uploaded_at <=', "$today 23:59:59")
            ->countAllResults();
        $validation_out = $validationModel->where('in_status', 0)
            ->where('uploaded_at >=', "$today 00:00:00")
            ->where('uploaded_at <=', "$today 23:59:59")
            ->countAllResults();

        // Repeat for other models; update column names accordingly
        $liquidation_in  = $liquidationModel->where('in_status', 1)
            ->where('uploaded_at >=', "$today 00:00:00")
            ->where('uploaded_at <=', "$today 23:59:59")
            ->countAllResults();
        $liquidation_out = $liquidationModel->where('in_status', 0)
            ->where('uploaded_at >=', "$today 00:00:00")
            ->where('uploaded_at <=', "$today 23:59:59")
            ->countAllResults();

        $disbursement_in  = $disbursementModel->where('in_status', 1)
            ->where('uploaded_at >=', "$today 00:00:00")
            ->where('uploaded_at <=', "$today 23:59:59")
            ->countAllResults();
        $disbursement_out = $disbursementModel->where('in_status', 0)
            ->where('uploaded_at >=', "$today 00:00:00")
            ->where('uploaded_at <=', "$today 23:59:59")
            ->countAllResults();

        $billing_in  = $billingModel->where('in_status', 1)
            ->where('uploaded_at >=', "$today 00:00:00")
            ->where('uploaded_at <=', "$today 23:59:59")
            ->countAllResults();
        $billing_out = $billingModel->where('in_status', 0)
            ->where('uploaded_at >=', "$today 00:00:00")
            ->where('uploaded_at <=', "$today 23:59:59")
            ->countAllResults();

        // --- General totals ---
        $total_in  = $validation_in + $liquidation_in + $disbursement_in + $billing_in;
        $total_out = $validation_out + $liquidation_out + $disbursement_out + $billing_out;

        // --- Chart data (last 7 days example) ---
        $dates = [];
        for ($i = 6; $i >= 0; $i--) {
            $dates[] = date('Y-m-d', strtotime("-$i days"));
        }

        $validation_chart = ['labels' => $dates, 'totals' => []];
        $liquidation_chart = ['labels' => $dates, 'totals' => []];
        $disbursement_chart = ['labels' => $dates, 'totals' => []];
        $billing_chart = ['labels' => $dates, 'totals' => []];

        foreach ($dates as $date) {
            $validation_chart['totals'][]   = $validationModel->where('in_status', 1)
                ->where('uploaded_at >=', "$date 00:00:00")
                ->where('uploaded_at <=', "$date 23:59:59")
                ->countAllResults();
            $liquidation_chart['totals'][]  = $liquidationModel->where('in_status', 1)
                ->where('uploaded_at >=', "$date 00:00:00")
                ->where('uploaded_at <=', "$date 23:59:59")
                ->countAllResults();
            $disbursement_chart['totals'][] = $disbursementModel->where('in_status', 1)
                ->where('uploaded_at >=', "$date 00:00:00")
                ->where('uploaded_at <=', "$date 23:59:59")
                ->countAllResults();
            $billing_chart['totals'][]      = $billingModel->where('in_status', 1)
                ->where('uploaded_at >=', "$date 00:00:00")
                ->where('uploaded_at <=', "$date 23:59:59")
                ->countAllResults();
        }

        $data = [
            'title'             => 'Dashboard',
            'validation_in'     => $validation_in,
            'validation_out'    => $validation_out,
            'liquidation_in'    => $liquidation_in,
            'liquidation_out'   => $liquidation_out,
            'disbursement_in'   => $disbursement_in,
            'disbursement_out'  => $disbursement_out,
            'billing_in'        => $billing_in,
            'billing_out'       => $billing_out,
            'total_in'          => $total_in,
            'total_out'         => $total_out,
            'validation_chart'  => $validation_chart,
            'liquidation_chart' => $liquidation_chart,
            'disbursement_chart'=> $disbursement_chart,
            'billing_chart'     => $billing_chart,
        ];

        return view('admin/dashboard', $data);
    }
}
