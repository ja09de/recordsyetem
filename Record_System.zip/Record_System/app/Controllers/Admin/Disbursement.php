<?php
namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\DisbursementModel;

class Disbursement extends BaseController
{
    protected $model;

    public function __construct()
    {
        $this->model = new DisbursementModel();
    }

    // List all disbursement files
    public function index()
    {
        $data['disbursements'] = $this->model->orderBy('created_at', 'DESC')->findAll();
        $data['title'] = 'Disbursement Files';
        return view('admin/disbursement', $data);
    }

    // Show create form
    public function create()
    {
        $data['title'] = 'Add Disbursement File';
        return view('admin/disbursement_create', $data);
    }

    // Store new file
    public function store()
    {
        $file = $this->request->getFile('file');
        $fileName = null;

        if ($file && $file->isValid() && !$file->hasMoved()) {
            // ✅ Save to public/uploads for direct URL access
            $fileName = $file->getRandomName();
            $file->move(FCPATH . 'uploads', $fileName);
        }

        $this->model->insert([
            'record_name' => $this->request->getPost('record_name') ?: 'Auto-Generated',
            'file' => $fileName,
            'in_status' => 1,
            'uploaded_at' => date('Y-m-d H:i:s')
        ]);

        return redirect()->to('admin/disbursement')->with('success', 'File added successfully.');
    }

    // Toggle In/Out status
    public function toggleInOut($id)
    {
        $record = $this->model->find($id);
        if ($record) {
            $newStatus = ($record['in_status'] ?? 0) ? 0 : 1;
            $this->model->update($id, ['in_status' => $newStatus]);
        }
        return redirect()->back();
    }

    // Delete record
    public function delete($id)
    {
        $record = $this->model->find($id);

        if ($record && !empty($record['file']) && file_exists(FCPATH . 'uploads/' . $record['file'])) {
            unlink(FCPATH . 'uploads/' . $record['file']); // delete the file physically
        }

        $this->model->delete($id);
        return redirect()->back()->with('success', 'Record deleted.');
    }

    // Edit form
    public function edit($id)
    {
        $disbursement = $this->model->find($id);

        if (!$disbursement) {
            return redirect()->to('admin/disbursement')->with('error', 'File not found.');
        }

        $data = [
            'title' => 'Edit Disbursement File',
            'disbursement' => $disbursement
        ];

        return view('admin/disbursement_edit', $data);
    }

    // Update record
    public function update($id)
    {
        $file = $this->request->getFile('file');
        $existingFile = $this->request->getPost('existing_file');
        $fileName = $existingFile;

        if ($file && $file->isValid() && !$file->hasMoved()) {
            $fileName = $file->getRandomName();
            $file->move(FCPATH . 'uploads', $fileName);

            // Delete old file
            if ($existingFile && file_exists(FCPATH . 'uploads/' . $existingFile)) {
                unlink(FCPATH . 'uploads/' . $existingFile);
            }
        }

        $this->model->update($id, [
            'record_name' => $this->request->getPost('record_name') ?: 'Auto-Generated',
            'file' => $fileName
        ]);

        return redirect()->to('admin/disbursement')->with('success', 'File updated successfully.');
    }
}
