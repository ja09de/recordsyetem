<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\LiquidationModel;

class Liquidations extends BaseController
{
    protected $model;

    public function __construct()
    {
        $this->model = new LiquidationModel();
    }

    // LIST / INDEX
    public function index()
    {
        $keyword = $this->request->getGet('keyword');

        if ($keyword) {
            $liquidations = $this->model->like('record_name', $keyword)->orderBy('id', 'DESC')->findAll();
        } else {
            $liquidations = $this->model->orderBy('id', 'DESC')->findAll();
        }

        return view('admin/liquidations', [
            'title' => 'Liquidations',
            'liquidations' => $liquidations,
            'keyword' => $keyword
        ]);
    }
    public function viewFile($filename)
{
    $path = WRITEPATH . 'uploads/' . $filename;
    if (!file_exists($path)) {
        throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound("File not found");
    }

    return $this->response->download($path, null)->setFileName($filename);
}


    // CREATE VIEW
    public function create()
    {
        return view('admin/liquidations_create', ['title' => 'Add Liquidation']);
    }

    // STORE
    public function store()
    {
        $file = $this->request->getFile('file');

        if (!$file || !$file->isValid()) {
            return redirect()->back()->with('error', 'No file uploaded or invalid file.');
        }

        $newName = $file->getRandomName();
        $file->move('uploads', $newName);

        $recordName = $this->request->getPost('record_name');

        $this->model->save([
            'record_name' => $recordName,
            'file' => $newName,
            'in_status' => 0,
            'uploaded_at' => date('Y-m-d H:i:s')
        ]);

        return redirect()->to(site_url('admin/liquidations'))->with('success', 'File uploaded successfully.');
    }

    // EDIT VIEW
    public function edit($id)
    {
        $liquidation = $this->model->find($id);
        if (!$liquidation) {
            return redirect()->to(site_url('admin/liquidations'))->with('error', 'Record not found.');
        }

        return view('admin/liquidations_edit', [
            'title' => 'Edit Liquidation',
            'liquidation' => $liquidation
        ]);
    }

    // UPDATE
    public function update($id)
    {
        $liquidation = $this->model->find($id);
        if (!$liquidation) {
            return redirect()->to(site_url('admin/liquidations'))->with('error', 'Record not found.');
        }

        $recordName = $this->request->getPost('record_name');

        $data = ['record_name' => $recordName];

        $file = $this->request->getFile('file');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            $newName = $file->getRandomName();
            $file->move('uploads', $newName);
            $data['file'] = $newName;
        }

        $this->model->update($id, $data);

        return redirect()->to(site_url('admin/liquidations'))->with('success', 'Record updated successfully.');
    }

    // TOGGLE IN/OUT
    public function toggleInOut($id)
    {
        $record = $this->model->find($id);
        if ($record) {
            $this->model->update($id, [
                'in_status' => $record['in_status'] ? 0 : 1
            ]);
        }
        return redirect()->back()->with('success', 'Status updated!');
    }

    // DELETE
    public function delete($id)
    {
        $record = $this->model->find($id);
        if ($record && file_exists('uploads/'.$record['file'])) {
            unlink('uploads/'.$record['file']);
        }
        $this->model->delete($id);

        return redirect()->back()->with('success', 'Record deleted!');
    }
}
