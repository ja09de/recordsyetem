<?php
namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\ScholarModel;

class Scholar extends BaseController
{
    protected $model;

    public function __construct()
    {
        $this->model = new ScholarModel();
    }

    // Read
    public function index()
    {
        $data['scholars'] = $this->model->where('is_archived', 0)->findAll();
        $data['title'] = 'Scholars';
        return view('admin/scholar/index', $data);
    }

    // Create
    public function create()
    {
        $data['title'] = 'Add Scholar';
        return view('admin/scholar/create', $data);
    }

    public function store()
    {
        $this->model->save([
            'fullname' => $this->request->getPost('fullname'),
            'email' => $this->request->getPost('email'),
            'scholarship' => $this->request->getPost('scholarship')
        ]);

        return redirect()->to('admin/scholar')->with('success', 'Scholar added successfully');
    }

    // Update
    public function edit($id)
    {
        $data['scholar'] = $this->model->find($id);
        $data['title'] = 'Edit Scholar';
        return view('admin/scholar/edit', $data);
    }

    public function update($id)
    {
        $this->model->update($id, [
            'fullname' => $this->request->getPost('fullname'),
            'email' => $this->request->getPost('email'),
            'scholarship' => $this->request->getPost('scholarship')
        ]);

        return redirect()->to('admin/scholar')->with('success', 'Scholar updated successfully');
    }

    // Delete (Soft archive)
    public function archive($id)
    {
        $this->model->update($id, ['is_archived' => 1]);
        return redirect()->to('admin/scholar')->with('success', 'Scholar archived');
    }

    // Restore
    public function restore($id)
    {
        $this->model->update($id, ['is_archived' => 0]);
        return redirect()->to('admin/scholar/archived')->with('success', 'Scholar restored');
    }

    // Lock finalized
    public function lock($id)
    {
        $this->model->update($id, ['status' => 'Finalized']);
        return redirect()->to('admin/scholar')->with('success', 'Record finalized and locked');
    }

    // Archived view
    public function archived()
    {
        $data['scholars'] = $this->model->where('is_archived', 1)->findAll();
        $data['title'] = 'Archived Scholars';
        return view('admin/scholar/archived', $data);
    }
}
