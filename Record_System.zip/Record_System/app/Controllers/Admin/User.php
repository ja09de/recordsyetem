<?php
namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\UserModel;

class User extends BaseController
{
    protected $userModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
    }

    // List all users
    public function index()
    {
        $data['users'] = $this->userModel->orderBy('id', 'DESC')->findAll();
        $data['title'] = 'User Management';
        return view('admin/user/index', $data);
    }

    // Show form to create a new user
    public function create()
    {
        $data['title'] = 'Add New User';
        return view('admin/user/create', $data);
    }

    // Save new user
    public function store()
    {
        $validation = \Config\Services::validation();

        if(!$this->validate([
            'fullname' => 'required|is_unique[users.fullname]',
            'email'    => 'required|valid_email|is_unique[users.email]',
            'password' => 'required|min_length[6]',
            'profile_pic' => 'uploaded[profile_pic]|is_image[profile_pic]|max_size[profile_pic,2048]',
        ])) {
            return redirect()->back()->withInput()->with('errors', $validation->getErrors());
        }

        $file = $this->request->getFile('profile_pic');
        $filename = $file->getRandomName();
        $file->move(WRITEPATH . 'uploads/users', $filename);

        $this->userModel->save([
            'username' => $this->request->getPost('username'),
            'email'    => $this->request->getPost('email'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
            'profile_pic' => $filename,
        ]);

        return redirect()->to('admin/user')->with('success', 'User added successfully.');
    }

    // Show edit form
    public function edit($id)
    {
        $data['user'] = $this->userModel->find($id);
        $data['title'] = 'Edit User';
        if(!$data['user']){
            return redirect()->to('admin/user')->with('error', 'User not found.');
        }
        return view('admin/user/edit', $data);
    }

    // Update user
    public function update($id)
    {
        $user = $this->userModel->find($id);
        if(!$user){
            return redirect()->to('admin/user')->with('error', 'User not found.');
        }

        $validation = \Config\Services::validation();
        if(!$this->validate([
            'username' => 'required',
            'email'    => 'required|valid_email',
            'profile_pic' => 'permit_empty|is_image[profile_pic]|max_size[profile_pic,2048]',
        ])){
            return redirect()->back()->withInput()->with('errors', $validation->getErrors());
        }

        $data = [
            'fullname' => $this->request->getPost('fullname'),
            'email'    => $this->request->getPost('email'),
        ];

        $file = $this->request->getFile('profile_pic');
        if($file && $file->isValid() && !$file->hasMoved()){
            $filename = $file->getRandomName();
            $file->move(WRITEPATH . 'uploads/users', $filename);
            $data['profile_pic'] = $filename;

            // Delete old file
            if(!empty($user['profile_pic']) && file_exists(WRITEPATH.'uploads/users/'.$user['profile_pic'])){
                unlink(WRITEPATH.'uploads/users/'.$user['profile_pic']);
            }
        }

        $this->userModel->update($id, $data);

        return redirect()->to('admin/user')->with('success', 'User updated successfully.');
    }

    // Delete user
    public function delete($id)
    {
        $user = $this->userModel->find($id);
        if($user){
            if(!empty($user['profile_pic']) && file_exists(WRITEPATH.'uploads/users/'.$user['profile_pic'])){
                unlink(WRITEPATH.'uploads/users/'.$user['profile_pic']);
            }
            $this->userModel->delete($id);
            return redirect()->to('admin/user')->with('success', 'User deleted successfully.');
        }
        return redirect()->to('admin/user')->with('error', 'User not found.');
    }
    public function uploadFile($id){
    $file = $this->request->getFile('file');

    if ($file && $file->isValid() && !$file->hasMoved()) {
        $newName = $file->getRandomName();
        $file->move(WRITEPATH . 'uploads', $newName);

        // Update the record with the file name
        $model = new YourModel(); // Example: BillingModel, LiquidationModel
        $model->update($id, ['file' => $newName]);

        return redirect()->back()->with('success', 'File uploaded successfully.');
    } else {
        return redirect()->back()->with('error', 'File upload failed.');
    }
}

}
