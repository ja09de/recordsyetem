<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\ValidationModel;

class Validation extends BaseController
{
    protected $model;

    public function __construct()
    {
        $this->model = new ValidationModel();
    }

    // List all files
    public function index()
    {
        $data = [
            'title' => 'Validation Records',
            'files' => $this->model->orderBy('uploaded_at', 'DESC')->findAll()
        ];
        return view('admin/validation', $data);
    }

    // Show create form
    public function create()
    {
        return view('admin/validation_create', ['title' => 'Add File']);
    }

    // Store new file
    public function store()
    {
        $recordName = $this->request->getPost('record_name');
        $uploadedFile = $this->request->getFile('file');
        $fileName = null;

        if ($uploadedFile && $uploadedFile->isValid() && !$uploadedFile->hasMoved()) {
            $fileName = $uploadedFile->getRandomName();
            $uploadedFile->move(FCPATH . 'uploads', $fileName);
        }

        $this->model->insert([
            'record_name' => $recordName ?: 'Auto-Generated',
            'file' => $fileName,
            'in_status' => 1,
            'uploaded_at' => date('Y-m-d H:i:s')
        ]);

        return redirect()->to(site_url('admin/validation'))->with('success', 'File record saved!');
    }

    // Toggle In/Out status
    public function toggleInOut($id)
    {
        $file = $this->model->find($id);

        if ($file) {
            $file['in_status'] = ($file['in_status'] == 1) ? 0 : 1;
            $this->model->save($file);
        }

        return redirect()->to(site_url('admin/validation'));
    }

    // Delete record and physical file
    public function delete($id)
    {
        $file = $this->model->find($id);

        if ($file && !empty($file['file'])) {
            $filePath = FCPATH . 'uploads/' . $file['file'];
            if (file_exists($filePath)) {
                unlink($filePath);
            }
        }

        $this->model->delete($id);

        return redirect()->back()->with('success', 'Deleted');
    }

    // View file (PDF inline, others download)
    public function viewFile($filename)
    {
        $filepath = FCPATH . 'uploads/' . $filename;

        if (!file_exists($filepath)) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('File not found.');
        }

        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

        if ($ext === 'pdf') {
            return $this->response->setFile($filepath)
                                  ->setHeader('Content-Type', 'application/pdf')
                                  ->setHeader('Content-Disposition', 'inline; filename="' . $filename . '"');
        }

        return $this->response->download($filepath, null);
    }
     public function edit($id)
    {
        $validationModel = new ValidationModel();
        $data = [
            'validation' => $validationModel->find($id),
            'title' => 'Edit Validation'
        ];
        return view('admin/validation_edit/', $data);
    }

    public function update($id)
    {
        $validationModel = new ValidationModel();

        $validationModel->update($id, [
            'field1' => $this->request->getPost('field1'),
            'field2' => $this->request->getPost('field2'),
            // add all fields here
        ]);

        return redirect()->to('/admin/validation_list');
    }
}
