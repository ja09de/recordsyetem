<?php

namespace App\Controllers;

use App\Models\UserModel;

class Auth extends BaseController
{
    public function login()
    {
        return view('auth/login');
    }

    public function register()
    {
        return view('auth/register');
    }

    public function save()
    {
        $model = new UserModel();

        $model->save([
            'fullname' => $this->request->getPost('fullname'),
            'email'    => $this->request->getPost('email'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
            'role'     => $this->request->getPost('role'),
            'status'   => 'active'
        ]);

        return redirect()->to('auth/login')->with('success', 'Account Created!');
    }

   public function process()
{
    $email    = $this->request->getPost('email');
    $password = $this->request->getPost('password');

    if(!$email || !$password){
        return redirect()->back()->with('error', 'Email or password is missing.');
    }

    $userModel = new \App\Models\UserModel();
    $user = $userModel->where('email', $email)->first();

    if(!$user){
        return redirect()->back()->with('error', 'Account not found.');
    }

    if(!password_verify($password, $user['password'])){
        return redirect()->back()->with('error', 'Invalid password.');
    }

    if($user['status'] !== 'active'){
        return redirect()->back()->with('error', 'Account is inactive.');
    }

    session()->set([
        'id'    => $user['id'],
        'name'  => $user['fullname'],
        'email' => $user['email'],
        'role'  => $user['role'],
        'logged_in' => true
    ]);

    // ✅✅ HERE IS THE REAL FIX
    if($user['role'] === 'admin'){
        return redirect()->to('admin/dashboard');
    }else{
        return redirect()->to('user/dashboard');
    }
}

     public function logout()
    {
        // Destroy the session
        session()->destroy();

        // Redirect to login page or home
        return redirect()->to('/auth/login');
    }
}
