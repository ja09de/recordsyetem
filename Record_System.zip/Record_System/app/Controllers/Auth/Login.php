<?php

namespace App\Controllers;

use App\Models\UserModel;

class Auth extends BaseController
{
    public function login()
    {
        if ($this->request->getMethod() === 'post') {
            $email = $this->request->getPost('email');
            $password = $this->request->getPost('password');

            $userModel = new UserModel();
            $user = $userModel->where('email', $email)->first();

            if ($user && password_verify($password, $user['password'])) {

                // Set session
                session()->set([
                    'user_id'    => $user['id'],
                    'fullname'   => $user['fullname'],
                    'role'       => $user['role'],
                    'isLoggedIn' => true
                ]);

                // Redirect based on role
                switch ($user['role']) {
                    case 'superadmin':
                        return redirect()->to('/superadmin/dashboard'); // analytics + user management
                    case 'admin':
                    case 'user':
                        return redirect()->to('/dashboard'); // file management modules
                    default:
                        return redirect()->to('/'); // fallback
                }

            } else {
                return redirect()->back()->with('error', 'Invalid email or password.');
            }
        }

        return view('auth/login');
    }
    public function loginPost()
{
    $email = $this->request->getPost('email');
    $password = $this->request->getPost('password');

    $user = $this->userModel->where('email', $email)->first();

    if ($user && password_verify($password, $user['password'])) {
        session()->set([
            'user_id' => $user['id'],
            'role' => $user['role'],
            'logged_in' => true
        ]);

        // Redirect based on role
        if ($user['role'] === 'superadmin') {
            return redirect()->to('/superadmin/dashboard');
        } elseif ($user['role'] === 'admin') {
            return redirect()->to('/admin/dashboard');
        } else {
            return redirect()->to('/user/dashboard');
        }
    } else {
        return redirect()->back()->with('error', 'Invalid credentials');
    }
}


    public function logout()
    {
        session()->destroy();
        return redirect()->to('/login');
    }
}
