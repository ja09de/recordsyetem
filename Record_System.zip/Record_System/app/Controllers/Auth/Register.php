<?php
namespace App\Controllers\Auth;

use App\Controllers\BaseController;
use App\Models\UserModel;

class Register extends BaseController
{
    public function index()
    {
        return view('auth/register'); // <-- specify the subfolder
    }

    public function save()
    {
        $userModel = new UserModel();

        $fullname = $this->request->getPost('fullname');
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');
        $role = $this->request->getPost('role');

        if($userModel->where('email', $email)->first()){
            return redirect()->back()->with('error','Email already exists.');
        }

        $userModel->insert([
            'fullname' => $fullname,
            'email' => $email,
            'password' => password_hash($password, PASSWORD_DEFAULT),
            'role' => $role,
            'status' => 'active'
        ]);

        return redirect()->to('/login')->with('success','Account created successfully! You can now login.');
    }
}
