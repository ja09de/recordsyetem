<?php
namespace App\Controllers;
use App\Controllers\BaseController;
use App\Models\UserModel;
use App\Models\ValidationModel;
use App\Models\LiquidationModel;
use App\Models\DisbursementModel;
use App\Models\BillingModel;

class SuperAdminController extends BaseController
{
   public function dashboard()
    {
        $validationModel   = new ValidationModel();
        $liquidationModel  = new LiquidationModel();
        $disbursementModel = new DisbursementModel();
        $billingModel      = new BillingModel();

        $today = date('Y-m-d');

        // Totals IN/OUT
        $validation_in  = $validationModel->where('in_status',1)->countAllResults();
        $validation_out = $validationModel->where('in_status',0)->countAllResults();
        $liquidation_in  = $liquidationModel->where('in_status',1)->countAllResults();
        $liquidation_out = $liquidationModel->where('in_status',0)->countAllResults();
        $disbursement_in  = $disbursementModel->where('in_status',1)->countAllResults();
        $disbursement_out = $disbursementModel->where('in_status',0)->countAllResults();
        $billing_in  = $billingModel->where('in_status',1)->countAllResults();
        $billing_out = $billingModel->where('in_status',0)->countAllResults();

        // Chart data for last 7 days
        $dates = [];
        for ($i = 6; $i >= 0; $i--) {
            $dates[] = date('Y-m-d', strtotime("-$i days"));
        }

        $validation_chart = ['labels'=>$dates, 'totals'=>[]];
        $liquidation_chart = ['labels'=>$dates, 'totals'=>[]];
        $disbursement_chart = ['labels'=>$dates, 'totals'=>[]];
        $billing_chart = ['labels'=>$dates, 'totals'=>[]];

        foreach($dates as $date) {
            $validation_chart['totals'][] = $validationModel->where('in_status',1)
                ->where('uploaded_at >=', "$date 00:00:00")
                ->where('uploaded_at <=', "$date 23:59:59")
                ->countAllResults();

            $liquidation_chart['totals'][] = $liquidationModel->where('in_status',1)
                ->where('uploaded_at >=', "$date 00:00:00")
                ->where('uploaded_at <=', "$date 23:59:59")
                ->countAllResults();

            $disbursement_chart['totals'][] = $disbursementModel->where('in_status',1)
                ->where('uploaded_at >=', "$date 00:00:00")
                ->where('uploaded_at <=', "$date 23:59:59")
                ->countAllResults();

            $billing_chart['totals'][] = $billingModel->where('in_status',1)
                ->where('uploaded_at >=', "$date 00:00:00")
                ->where('uploaded_at <=', "$date 23:59:59")
                ->countAllResults();
        }

        return view('superadmin/dashboard', [
            'title' => 'SuperAdmin Dashboard',
            'total_in' => $validation_in + $liquidation_in + $disbursement_in + $billing_in,
            'total_out'=> $validation_out + $liquidation_out + $disbursement_out + $billing_out,
            'validation_in'=>$validation_in,
            'validation_out'=>$validation_out,
            'liquidation_in'=>$liquidation_in,
            'liquidation_out'=>$liquidation_out,
            'disbursement_in'=>$disbursement_in,
            'disbursement_out'=>$disbursement_out,
            'billing_in'=>$billing_in,
            'billing_out'=>$billing_out,
            'validation_chart'=>$validation_chart,
            'liquidation_chart'=>$liquidation_chart,
            'disbursement_chart'=>$disbursement_chart,
            'billing_chart'=>$billing_chart
        ]);
    }

    public function storeUser()
    {
        $data = $this->request->getPost();
        $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);

        $this->userModel->save($data);

        return redirect()->to('superadmin')->with('success', 'User created successfully');
    }

    public function editUser($id)
    {
        $user = $this->userModel->find($id);
        return view('superadmin/edit_user', [
            'title' => 'Edit User',
            'user' => $user
        ]);
    }

    public function updateUser($id)
    {
        $data = $this->request->getPost();

        // Hash password only if it's not empty
        if (!empty($data['password'])) {
            $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
        } else {
            unset($data['password']);
        }

        $this->userModel->update($id, $data);

        return redirect()->to('superadmin')->with('success', 'User updated successfully');
    }

    public function deleteUser($id)
    {
        $this->userModel->delete($id);
        return redirect()->to('superadmin')->with('success', 'User deleted successfully');
    }
    public function userManagement()
{
    $users = (new \App\Models\UserModel())->findAll();

    return view('superadmin/users', [
        'title' => 'User Management',
        'users' => $users
    ]);
}

}
