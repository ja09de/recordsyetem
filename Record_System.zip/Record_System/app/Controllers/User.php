<?= $this->extend('admin/layout') ?>
<?= $this->section('content') ?>

<h2 class="text-2xl font-bold mb-4"><?= esc($title) ?></h2>

<table class="w-full border">
    <thead>
        <tr class="bg-gray-100">
            <th class="border px-2 py-1">ID</th>
            <th class="border px-2 py-1">Username</th>
            <th class="border px-2 py-1">Email</th>
            <th class="border px-2 py-1">Role</th>
            <th class="border px-2 py-1">Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($users as $user): ?>
        <tr>
            <td class="border px-2 py-1"><?= $user['id'] ?></td>
            <td class="border px-2 py-1"><?= esc($user['username']) ?></td>
            <td class="border px-2 py-1"><?= esc($user['email']) ?></td>
            <td class="border px-2 py-1"><?= $user['role'] ?></td>
            <td class="border px-2 py-1">
                <a href="<?= site_url('superadmin/users/edit/'.$user['id']) ?>" class="text-blue-600">Edit</a>
                <a href="<?= site_url('superadmin/users/delete/'.$user['id']) ?>" class="text-red-600 ml-2">Delete</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?= $this->endSection() ?>
