<?php
namespace App\Controllers\User;

use App\Controllers\BaseController;
use App\Models\ValidationModel;
use App\Models\LiquidationModel;
use App\Models\DisbursementModel;
use App\Models\BillingModel;

class Dashboard extends BaseController
{
    public function index()
    {
        $userId = session()->get('user_id');

        $validation = new ValidationModel();
        $liquidation = new LiquidationModel();
        $disbursement = new DisbursementModel();
        $billing = new BillingModel();

        // TOTALS
        $data['total_in']  =
            $validation->where('user_id', $userId)->where('in_status', 1)->countAllResults()
          + $liquidation->where('user_id', $userId)->where('in_status', 1)->countAllResults()
          + $disbursement->where('user_id', $userId)->where('in_status', 1)->countAllResults()
          + $billing->where('user_id', $userId)->where('in_status', 1)->countAllResults();

        $data['total_out'] =
            $validation->where('user_id', $userId)->where('in_status', 0)->countAllResults()
          + $liquidation->where('user_id', $userId)->where('in_status', 0)->countAllResults()
          + $disbursement->where('user_id', $userId)->where('in_status', 0)->countAllResults()
          + $billing->where('user_id', $userId)->where('in_status', 0)->countAllResults();

        // PER MODULE
        $data['validation_in']  = $validation->where('user_id', $userId)->where('in_status', 1)->countAllResults();
        $data['validation_out'] = $validation->where('user_id', $userId)->where('in_status', 0)->countAllResults();

        $data['liquidation_in']  = $liquidation->where('user_id', $userId)->where('in_status', 1)->countAllResults();
        $data['liquidation_out'] = $liquidation->where('user_id', $userId)->where('in_status', 0)->countAllResults();

        $data['disbursement_in']  = $disbursement->where('user_id', $userId)->where('in_status', 1)->countAllResults();
        $data['disbursement_out'] = $disbursement->where('user_id', $userId)->where('in_status', 0)->countAllResults();

        $data['billing_in']  = $billing->where('user_id', $userId)->where('in_status', 1)->countAllResults();
        $data['billing_out'] = $billing->where('user_id', $userId)->where('in_status', 0)->countAllResults();

        // CHART DATA (example: validation per day)
        $data['validation_chart'] = $validation
            ->select("DATE(uploaded_at) as day, COUNT(*) as total")
            ->where('user_id', $userId)
            ->groupBy('day')
            ->orderBy('day', 'ASC')
            ->findAll();

        return view('user/dashboard', $data);
    }
}
