<?php

namespace App\Controllers\User;

use App\Controllers\BaseController;
use App\Models\ValidationModel;

class Validation extends BaseController
{
    protected $model;

    public function __construct()
    {
        $this->model = new ValidationModel();
    }

    // List all files
    public function index()
    {
        $data = [
            'title' => 'Validation Records',
            'files' => $this->model->orderBy('uploaded_at', 'DESC')->findAll()
        ];
        return view('user/validation_list', $data);
    }

    // Show create form
    public function create()
    {
        return view('user/validation_add', ['title' => 'Add File']);
    }

public function store()
{
    $recordName = $this->request->getPost('record_name');
    $uploadedFile = $this->request->getFile('file');
    $fileName = null;

    if ($uploadedFile && $uploadedFile->isValid() && !$uploadedFile->hasMoved()) {
        $fileName = $uploadedFile->getRandomName();
        $uploadedFile->move(FCPATH . 'uploads', $fileName);
    }

    // 1️⃣ Save in the user table
    $this->userModel->insert([
        'user_id' => session()->get('id'), // link to the current user
        'record_name' => $recordName ?: 'Auto-Generated',
        'file' => $fileName,
        'in_status' => 1, // default IN
        'uploaded_at' => date('Y-m-d H:i:s')
    ]);

    // 2️⃣ Save in the admin table (so admin can monitor)
    $this->adminModel->insert([
        'user_id' => session()->get('id'), // store user who uploaded
        'record_name' => $recordName ?: 'Auto-Generated',
        'file' => $fileName,
        'in_status' => 1,
        'uploaded_at' => date('Y-m-d H:i:s')
    ]);

    return redirect()->to(site_url('user/validation_list'))->with('success', 'File record saved for user and admin!');
}


    // Toggle In/Out status
    public function toggleInOut($id)
    {
        $file = $this->model->find($id);

        if ($file) {
            $file['in_status'] = ($file['in_status'] == 1) ? 0 : 1;
            $this->model->save($file);
        }

        return redirect()->to(site_url('user/validation_list'));
    }

    // Delete record and physical file
    public function delete($id)
    {
        $file = $this->model->find($id);

        if ($file && !empty($file['file'])) {
            $filePath = FCPATH . 'uploads/' . $file['file'];
            if (file_exists($filePath)) {
                unlink($filePath);
            }
        }

        $this->model->delete($id);

        return redirect()->back()->with('success', 'Deleted');
    }

    // View file (PDF inline, others download)
    public function viewFile($filename)
    {
        $filepath = FCPATH . 'uploads/' . $filename;

        if (!file_exists($filepath)) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('File not found.');
        }

        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

        if ($ext === 'pdf') {
            return $this->response->setFile($filepath)
                                  ->setHeader('Content-Type', 'application/pdf')
                                  ->setHeader('Content-Disposition', 'inline; filename="' . $filename . '"');
        }

        return $this->response->download($filepath, null);
    }
}
