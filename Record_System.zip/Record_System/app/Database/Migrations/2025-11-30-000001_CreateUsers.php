<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateUsers extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'         => ['type'=>'INT','constraint'=>11,'auto_increment'=>true],
            'fullname'   => ['type'=>'VARCHAR','constraint'=>150],
            'email'      => ['type'=>'VARCHAR','constraint'=>150,'unique'=>true],
            'password'   => ['type'=>'VARCHAR','constraint'=>255],
            'role'       => ['type'=>'ENUM("admin","user")','default'=>'user'],
            'created_at' => ['type'=>'DATETIME','null'=>true],
            'updated_at' => ['type'=>'DATETIME','null'=>true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->createTable('users');
    }

    public function down()
    {
        $this->forge->dropTable('users');
    }
}
