<?php

namespace App\Filters;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Filters\FilterInterface;

class SuperAdminFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $session = session();
        if ($session->get('role') !== 'superadmin') {
            return redirect()->to('/dashboard'); // send non-superadmins to user/admin dashboard
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null) {}
}
