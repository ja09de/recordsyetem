<?php

namespace App\Filters;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Filters\FilterInterface;

class UserFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $session = session();
        if (!in_array($session->get('role'), ['admin', 'user'])) {
            return redirect()->to('/superadmin/dashboard'); // superadmin cannot access user module
        }
    }

    public function after(RequestInterface $request, $response, $arguments = null) {}
}
