<?php

namespace App\Models;

use CodeIgniter\Model;

class AdminValidationModel extends Model
{
    protected $table = 'admin_validations';
    protected $allowedFields = ['user_id','record_name','file','in_status','uploaded_at'];
    protected $useTimestamps = false;
}
