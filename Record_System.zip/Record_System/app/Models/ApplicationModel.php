<?php
namespace App\Models;
use CodeIgniter\Model;

class ApplicationModel extends Model {
    protected $table = 'applications';
    protected $allowedFields = ['user_id','scholarship_name','amount','status'];
    protected $useTimestamps = true;
}
