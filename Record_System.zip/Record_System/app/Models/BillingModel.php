<?php

namespace App\Models;

use CodeIgniter\Model;

class BillingModel extends Model
{
    protected $table = 'billing';
    protected $primaryKey = 'id';
    protected $allowedFields = ['record_name', 'file', 'in_status', 'uploaded_at'];
    protected $useTimestamps = false; // or true kung gusto mo auto created_at, updated_at
}
