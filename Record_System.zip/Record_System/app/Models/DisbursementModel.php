<?php
namespace App\Models;

use CodeIgniter\Model;

class DisbursementModel extends Model
{
    protected $table = 'disbursements';
    protected $primaryKey = 'id';
    protected $allowedFields = ['record_name', 'file', 'in_status', 'uploaded_at'];
    protected $useTimestamps = false;
}
