<?php

namespace App\Models;

use CodeIgniter\Model;

class LiquidationModel extends Model
{
    protected $table = 'liquidations';
    protected $primaryKey = 'id';
    protected $useTimestamps = true;

    protected $allowedFields = [
        'record_name',
        'file',
        'in_status',
        'uploaded_at',
        'created_at',
        'updated_at'
    ];
}
