<?php
namespace App\Models;

use CodeIgniter\Model;

class ScholarModel extends Model
{
    protected $table = 'scholars';
    protected $primaryKey = 'id';
    protected $allowedFields = ['fullname', 'email', 'scholarship', 'status', 'is_archived'];
    protected $useTimestamps = true;
}
