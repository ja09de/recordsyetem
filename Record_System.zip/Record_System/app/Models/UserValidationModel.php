<?php

namespace App\Models;

use CodeIgniter\Model;

class UserValidationModel extends Model
{
    protected $table = 'user_validations';
    protected $allowedFields = ['user_id','record_name','file','in_status','uploaded_at'];
    protected $useTimestamps = false;
}
