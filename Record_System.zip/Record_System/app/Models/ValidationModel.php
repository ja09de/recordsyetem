<?php

namespace App\Models;
use CodeIgniter\Model;

class ValidationModel extends Model
{
    protected $table = 'validation_files';
    protected $primaryKey = 'id';

    protected $allowedFields = [
        'user_id',
        'record_name',
        'file',
        'in_status',
        'uploaded_at',
        'updated_at'
    ];

    protected $useTimestamps = false;
}


