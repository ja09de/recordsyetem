<?= $this->extend('admin/layout') ?>
<?= $this->section('content') ?>

<h2 class="text-2xl font-bold mb-4">Billing Files</h2>

<!-- TOP BAR -->
<div class="flex items-center justify-between mb-4">
    <div class="text-gray-600 text-sm">
        User can monitor and manage billing status
    </div>

    <div class="flex gap-3 items-center">
        <!-- ADD FILE -->
        <a href="<?= site_url('admin/billing_create') ?>"
           class="bg-green-700 hover:bg-green-800 text-white px-4 py-2 rounded shadow text-sm">
            ➕ Add File
        </a>

        <!-- SEARCH -->
        <div class="relative w-64">
            <input
                type="text"
                id="tableSearch"
                placeholder="Search record, file, status..."
                class="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-400"
            >
            <span class="absolute left-3 top-2.5 text-gray-400">🔍</span>
        </div>
    </div>
</div>

<!-- FLASH MESSAGES -->
<?php if(session()->getFlashdata('success')): ?>
    <div class="bg-green-100 border border-green-300 text-green-800 p-3 rounded mb-4">
        <?= session()->getFlashdata('success') ?>
    </div>
<?php endif; ?>

<?php if(session()->getFlashdata('error')): ?>
    <div class="bg-red-100 border border-red-300 text-red-800 p-3 rounded mb-4">
        <?= session()->getFlashdata('error') ?>
    </div>
<?php endif; ?>

<!-- TABLE -->
<div class="overflow-x-auto">
<table class="min-w-full bg-white shadow-lg rounded-lg overflow-hidden">
    <thead class="bg-teal-500 text-white text-sm uppercase tracking-wide">
        <tr>
            <th class="px-4 py-3 text-left">ID</th>
            <th class="px-4 py-3 text-left">Record</th>
            <th class="px-4 py-3 text-left">File</th>
            <th class="px-4 py-3 text-left">Status</th>
            <th class="px-4 py-3 text-left">Uploaded</th>
            <th class="px-4 py-3 text-center">Actions</th>
        </tr>
    </thead>

    <tbody>
    <?php if(!empty($billings)): ?>
        <?php foreach($billings as $b): ?>
        <tr class="border-b hover:bg-gray-50 transition">
            <td class="px-4 py-3"><?= $b['id'] ?></td>

            <td class="px-4 py-3 font-medium">
                <?= esc($b['record_name'] ?? 'Auto') ?>
            </td>

            <!-- FILE -->
            <td class="px-4 py-3">
                <?php if(!empty($b['file'])): ?>
                    <a href="<?= base_url('uploads/'.$b['file']) ?>" target="_blank"
                       class="inline-flex items-center gap-1 bg-blue-500 hover:bg-blue-600
                              text-white px-3 py-1 rounded-full text-xs font-semibold transition">
                        📄 View
                    </a>
                <?php else: ?>
                    <span class="text-gray-500 text-sm">No File</span>
                <?php endif; ?>
            </td>

            <!-- STATUS -->
            <td class="px-4 py-3">
                <span class="px-3 py-1 rounded-full text-xs font-bold
                    <?= ($b['in_status'] ?? 0) ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700' ?>">
                    <?= ($b['in_status'] ?? 0) ? 'IN' : 'OUT' ?>
                </span>
            </td>

            <td class="px-4 py-3 text-sm">
                <?= esc($b['uploaded_at'] ?? '-') ?>
            </td>

            <!-- ACTIONS -->
            <td class="px-4 py-3 flex justify-center gap-2 flex-wrap">

                <!-- MARK IN / OUT -->
                <a href="<?= site_url('admin/billing/toggleInOut/'.$b['id']) ?>"
                   class="px-3 py-1 rounded-full text-xs font-bold text-white transition
                   <?= ($b['in_status'] ?? 0) ? 'bg-red-500 hover:bg-red-600' : 'bg-green-500 hover:bg-green-600' ?>">
                    <?= ($b['in_status'] ?? 0) ? 'MARK OUT' : 'MARK IN' ?>
                </a>

               

                <!-- DELETE -->
                <a href="<?= site_url('admin/billing/delete/'.$b['id']) ?>"
                   onclick="return confirm('Delete this file?')"
                   class="px-3 py-1 rounded-full text-xs font-semibold bg-red-500 hover:bg-red-600
                          text-white transition">
                    🗑 Delete
                </a>
            </td>
        </tr>
        <?php endforeach; ?>
    <?php else: ?>
        <tr>
            <td colspan="6" class="text-center px-4 py-6 text-gray-500">
                No billing files found.
            </td>
        </tr>
    <?php endif; ?>
    </tbody>
</table>
</div>

<!-- SEARCH SCRIPT -->
<script>
document.getElementById('tableSearch').addEventListener('keyup', function () {
    let value = this.value.toLowerCase();
    document.querySelectorAll('tbody tr').forEach(row => {
        row.style.display = row.textContent.toLowerCase().includes(value)
            ? ''
            : 'none';
    });
});
</script>

<?= $this->endSection() ?>
