<?= $this->extend('admin/layout') ?>
<?= $this->section('content') ?>

<div class="max-w-xl mx-auto bg-white p-8 rounded-lg shadow-md mt-10">
    <h2 class="text-2xl font-bold mb-6 text-gray-800">Edit Billing Record</h2>

    <?php if (session()->getFlashdata('error')): ?>
        <div class="bg-red-100 text-red-700 p-3 rounded mb-4">
            <?= session()->getFlashdata('error') ?>
        </div>
    <?php endif; ?>

    <form action="<?= site_url('admin/billing/update/'.$billing['id']) ?>" method="post" enctype="multipart/form-data" class="space-y-5">
        <?= csrf_field() ?>

        <div>
            <label for="record_name" class="block text-gray-700 font-medium mb-2">Record Name</label>
            <input 
                type="text" 
                id="record_name" 
                name="record_name" 
                value="<?= esc($billing['record_name']) ?>" 
                required
                class="w-full border border-gray-300 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-teal-500"
            >
        </div>

        <div>
            <label for="file" class="block text-gray-700 font-medium mb-2">Upload File (optional)</label>
            <input 
                type="file" 
                id="file" 
                name="file" 
                class="w-full text-gray-600"
            >
            <?php if (!empty($billing['file'])): ?>
                <p class="mt-2 text-sm text-gray-500">Current file: <span class="font-medium"><?= esc($billing['file']) ?></span></p>
            <?php endif; ?>
        </div>

        <div class="flex justify-between items-center mt-6">
            <a href="<?= site_url('admin/billing') ?>" class="px-4 py-2 bg-gray-300 text-gray-700 rounded hover:bg-gray-400">Cancel</a>
            <button type="submit" class="px-6 py-2 bg-teal-600 text-white rounded hover:bg-teal-700 transition">Update Record</button>
        </div>
    </form>
</div>

<?= $this->endSection() ?>
