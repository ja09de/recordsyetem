<?= $this->extend('admin/layout') ?>
<?= $this->section('content') ?>

<h2 class="text-2xl font-bold mb-4"><?= esc($title) ?></h2>

<form action="<?= site_url('admin/disbursement/update/'.$disbursement['id']) ?>" method="post" enctype="multipart/form-data" class="space-y-4 max-w-md">
    <?= csrf_field() ?>
    
    <div>
        <label class="block mb-1 font-semibold">Record Name</label>
        <input type="text" name="record_name" value="<?= esc($disbursement['record_name']) ?>" class="border px-2 py-1 rounded w-full" required>
    </div>

    <div>
        <label class="block mb-1 font-semibold">Upload New File (optional)</label>
        <input type="file" name="file" class="border px-2 py-1 rounded w-full">
        <?php if(!empty($disbursement['file'])): ?>
            <p class="mt-1 text-gray-600">Current file: <a href="<?= base_url('uploads/'.$disbursement['file']) ?>" target="_blank"><?= esc($disbursement['file']) ?></a></p>
        <?php endif; ?>
    </div>

    <div>
        <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Update File</button>
    </div>
</form>

<?= $this->endSection()?> 
