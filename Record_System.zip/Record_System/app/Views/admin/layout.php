<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= $title ?? 'Admin Dashboard' ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="flex h-screen bg-gray-100">

<!-- Left Sidebar -->
<aside class="w-64 bg-teal-700 text-white flex-shrink-0 flex flex-col">

    <!-- Logo + System Name -->
    <div class="p-4 flex flex-col items-center border-b border-teal-500">
        <img src="<?= base_url('assets/images/sksu-logo.png') ?>" 
             alt="Logo" 
             class="w-16 h-16 object-contain mb-2">
        <span class="font-bold text-sm text-center leading-tight">
            Scholarship Records System<br>
            <span class="text-xs font-normal">User Panel</span>
        </span>
    </div>

    <!-- Navigation -->
    <nav class="mt-4 flex-1 text-sm">

        <a href="<?= site_url('admin/dashboard') ?>" 
           class="block py-3 px-4 hover:bg-teal-600 transition">
            📊 Dashboard
        </a>

        <a href="<?= site_url('admin/validation') ?>" 
           class="block py-3 px-4 hover:bg-teal-600 transition">
            ✅ Validation
        </a>

        <a href="<?= site_url('admin/disbursement') ?>" 
           class="block py-3 px-4 hover:bg-teal-600 transition">
            💸 Disbursements
        </a>

        <a href="<?= site_url('admin/liquidations') ?>" 
           class="block py-3 px-4 hover:bg-teal-600 transition">
            🧾 Liquidations
        </a>

        <a href="<?= site_url('admin/billing') ?>" 
           class="block py-3 px-4 hover:bg-teal-600 transition">
            🗂 Billing
        </a>

       

    </nav>

    <!-- Logout (Bottom) -->
    <div class="border-t border-teal-500">
        <a href="<?= site_url('auth/logout') ?>" 
           class="block py-3 px-4 hover:bg-red-600 transition text-center">
            🚪 Logout
        </a>
    </div>

</aside>

<!-- Main Content -->
<main class="flex-1 p-6 overflow-auto">
    <?= $this->renderSection('content') ?>
</main>

</body>
</html>
