<?= $this->extend('admin/layout') ?>
<?= $this->section('content') ?>

<h2 class="text-2xl font-bold mb-4"><?= esc($title) ?></h2>

<form action="<?= site_url('admin/liquidations/store') ?>" method="post" enctype="multipart/form-data" class="space-y-4 max-w-md">
    <div>
        <label class="block mb-1 font-semibold">Record Name</label>
        <input type="text" name="record_name" class="border px-2 py-1 rounded w-full" required>
    </div>

    <div>
        <label class="block mb-1 font-semibold">File (Optional)</label>
        <input type="file" name="file" class="border px-2 py-1 rounded w-full">
    </div>

    <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">
        Add File
    </button>
</form>

<?= $this->endSection() ?>
