<?= $this->extend('admin/layout') ?>
<?= $this->section('content') ?>

<h2 class="text-2xl font-bold mb-4"><?= esc($title) ?></h2>

<form action="<?= site_url('admin/liquidations/update/'.$liquidation['id']) ?>" method="post" enctype="multipart/form-data" class="space-y-2">
    <input type="text" name="record_name" value="<?= esc($liquidation['record_name']) ?>" required
           class="border px-2 py-1 rounded w-full">
    <input type="file" name="file" class="border px-2 py-1 rounded w-full">
    <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Update</button>
</form>

<?= $this->endSection() ?>
