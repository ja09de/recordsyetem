<?= $this->extend('admin/layout') ?>
<?= $this->section('content') ?>

<h2 class="text-2xl font-bold mb-4"><?= esc($title ?? 'Add User') ?></h2>

<form action="<?= site_url('admin/user/store') ?>" 
      method="post" 
      enctype="multipart/form-data"
      class="bg-white p-6 shadow rounded max-w-lg">

    <?= csrf_field() ?>

    <!-- Full Name -->
    <div class="mb-4">
        <label class="block text-sm font-medium mb-1">Full Name</label>
        <input type="text" 
               name="fullname" 
               required
               class="w-full border px-3 py-2 rounded"
               placeholder="Enter full name">
    </div>

    <!-- Email -->
    <div class="mb-4">
        <label class="block text-sm font-medium mb-1">Email</label>
        <input type="email" 
               name="email" 
               required
               class="w-full border px-3 py-2 rounded"
               placeholder="example@email.com">
    </div>

    <!-- Password -->
    <div class="mb-4">
        <label class="block text-sm font-medium mb-1">Password</label>
        <input type="password" 
               name="password" 
               required
               class="w-full border px-3 py-2 rounded"
               placeholder="Enter password">
    </div>

    <!-- Role -->
    <div class="mb-4">
        <label class="block text-sm font-medium mb-1">Role</label>
        <select name="role" class="w-full border px-3 py-2 rounded">
            <option value="user">User</option>
            <option value="admin">Admin</option>
        </select>
    </div>

    <!-- Profile Picture -->
    <div class="mb-4">
        <label class="block text-sm font-medium mb-1">Profile Picture</label>
        <input type="file" 
               name="profile_pic" 
               accept="image/*"
               class="w-full border px-3 py-2 rounded">
    </div>

    <!-- Buttons -->
    <div class="flex items-center space-x-3">
        <button type="submit" 
                class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded">
            Create User
        </button>

        <a href="<?= site_url('admin/user') ?>" 
           class="text-gray-600 hover:underline">
            Cancel
        </a>
    </div>

</form>

<?= $this->endSection() ?>
