<?= $this->extend('admin/layout') ?>
<?= $this->section('content') ?>

<h2 class="text-2xl font-bold mb-4">Edit User</h2>

<?php if(session()->getFlashdata('success')): ?>
<div class="bg-green-200 text-green-800 p-2 rounded mb-4">
    <?= session()->getFlashdata('success') ?>
</div>
<?php endif; ?>

<?php if(session()->getFlashdata('error')): ?>
<div class="bg-red-200 text-red-800 p-2 rounded mb-4">
    <?= session()->getFlashdata('error') ?>
</div>
<?php endif; ?>

<form action="<?= site_url('admin/user/update/'.$user['id']) ?>" method="post" enctype="multipart/form-data" class="bg-white p-4 rounded shadow-md max-w-lg">
    <?= csrf_field() ?>

    <div class="mb-4">
        <label class="block mb-1 font-semibold">Full Name</label>
        <input type="text" name="fullname" value="<?= old('fullname', $user['fullname']) ?>" class="w-full border rounded px-3 py-2" required>
    </div>

    <div class="mb-4">
        <label class="block mb-1 font-semibold">Email</label>
        <input type="email" name="email" value="<?= old('email', $user['email']) ?>" class="w-full border rounded px-3 py-2" required>
    </div>

    <div class="mb-4">
        <label class="block mb-1 font-semibold">Password <small>(Leave blank to keep current)</small></label>
        <input type="password" name="password" class="w-full border rounded px-3 py-2">
    </div>

    <div class="mb-4">
        <label class="block mb-1 font-semibold">Role</label>
        <select name="role" class="w-full border rounded px-3 py-2" required>
            <option value="admin" <?= $user['role']=='admin' ? 'selected' : '' ?>>Admin</option>
            <option value="user" <?= $user['role']=='user' ? 'selected' : '' ?>>User</option>
        </select>
    </div>

    <div class="mb-4">
        <label class="block mb-1 font-semibold">Status</label>
        <select name="status" class="w-full border rounded px-3 py-2" required>
            <option value="active" <?= $user['status']=='active' ? 'selected' : '' ?>>Active</option>
            <option value="inactive" <?= $user['status']=='inactive' ? 'selected' : '' ?>>Inactive</option>
        </select>
    </div>

    <div class="mb-4">
        <label class="block mb-1 font-semibold">Profile Picture</label>
        <?php if(!empty($user['profile_pic'])): ?>
            <img src="<?= base_url('writable/uploads/profile/'.$user['profile_pic']) ?>" alt="Profile" class="w-20 h-20 rounded mb-2">
        <?php endif; ?>
        <input type="file" name="profile_pic" class="border rounded px-3 py-2">
    </div>

    <div>
        <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Update User</button>
        <a href="<?= site_url('admin/user') ?>" class="ml-2 text-gray-600 hover:underline">Cancel</a>
    </div>
</form>

<?= $this->endSection() ?>
