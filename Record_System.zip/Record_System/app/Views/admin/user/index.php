<?= $this->extend('admin/layout') ?>
<?= $this->section('content') ?>

<h2 class="text-2xl font-bold mb-4"><?= esc($title) ?></h2>

<!-- TOP BAR -->
<div class="flex items-center justify-between mb-4">
    <a href="<?= site_url('admin/user/create') ?>"
       class="bg-blue-500 text-white px-4 py-2 rounded-lg font-semibold hover:bg-blue-600 transition">
        + Add User
    </a>

    <!-- SEARCH -->
    <div class="relative w-1/3">
        <input
            type="text"
            id="tableSearch"
            placeholder="Search name, email, role..."
            class="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-400"
        >
        <span class="absolute left-3 top-2.5 text-gray-400">🔍</span>
    </div>
</div>

<!-- FLASH MESSAGES -->
<?php if(session()->getFlashdata('success')): ?>
<div class="bg-green-200 text-green-800 p-3 rounded mb-4">
    <?= session()->getFlashdata('success') ?>
</div>
<?php endif; ?>

<?php if(session()->getFlashdata('error')): ?>
<div class="bg-red-200 text-red-800 p-3 rounded mb-4">
    <?= session()->getFlashdata('error') ?>
</div>
<?php endif; ?>

<!-- TABLE -->
<div class="overflow-x-auto">
<table class="min-w-full bg-white shadow-lg rounded-lg overflow-hidden">
    <thead class="bg-teal-500 text-white text-sm uppercase tracking-wide">
        <tr>
            <th class="px-4 py-3 text-left">ID</th>
            <th class="px-4 py-3 text-left">Full Name</th>
            <th class="px-4 py-3 text-left">Email</th>
            <th class="px-4 py-3 text-left">Role</th>
            <th class="px-4 py-3 text-left">Profile</th>
            <th class="px-4 py-3 text-center">Actions</th>
        </tr>
    </thead>

    <tbody>
        <?php if(!empty($users)): ?>
            <?php foreach($users as $user): ?>
            <tr class="border-b hover:bg-gray-50 transition">
                <td class="px-4 py-3"><?= $user['id'] ?></td>

                <td class="px-4 py-3 font-medium">
                    <?= esc($user['fullname']) ?>
                </td>

                <td class="px-4 py-3 text-sm">
                    <?= esc($user['email']) ?>
                </td>

                <!-- ROLE BADGE -->
                <td class="px-4 py-3">
                    <span class="px-3 py-1 rounded-full text-xs font-bold
                        <?= $user['role'] === 'admin'
                            ? 'bg-indigo-100 text-indigo-700'
                            : 'bg-gray-100 text-gray-700' ?>">
                        <?= ucfirst($user['role']) ?>
                    </span>
                </td>

                <!-- PROFILE -->
                <td class="px-4 py-3">
                    <?php if(!empty($user['profile_pic'])): ?>
                        <img
                            src="<?= base_url('writable/uploads/profile/'.$user['profile_pic']) ?>"
                            alt="Profile"
                            class="w-10 h-10 rounded-full object-cover border"
                        >
                    <?php else: ?>
                        <span class="text-gray-500 text-sm">No pic</span>
                    <?php endif; ?>
                </td>

                <!-- ACTIONS -->
                <td class="px-4 py-3 flex justify-center gap-2 flex-wrap">

                    <!-- EDIT -->
                    <a href="<?= site_url('admin/user/edit/'.$user['id']) ?>"
                       class="px-3 py-1 rounded-full text-xs font-semibold
                              bg-yellow-500 hover:bg-yellow-600 text-white transition">
                        ✏ Edit
                    </a>

                    <!-- DELETE -->
                    <a href="<?= site_url('admin/user/delete/'.$user['id']) ?>"
                       onclick="return confirm('Are you sure?')"
                       class="px-3 py-1 rounded-full text-xs font-semibold
                              bg-red-500 hover:bg-red-600 text-white transition">
                        🗑 Delete
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="6" class="text-center px-4 py-6 text-gray-500">
                    No users found.
                </td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
</div>

<!-- SEARCH SCRIPT -->
<script>
document.getElementById('tableSearch').addEventListener('keyup', function () {
    let value = this.value.toLowerCase();
    document.querySelectorAll('tbody tr').forEach(row => {
        row.style.display = row.textContent.toLowerCase().includes(value)
            ? ''
            : 'none';
    });
});
</script>

<?= $this->endSection() ?>
