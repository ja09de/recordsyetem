<?= $this->extend('admin/layout') ?>
<?= $this->section('content') ?>

<h2 class="text-2xl font-bold mb-4"><?= esc($title) ?></h2>

<?php if(session()->getFlashdata('error')): ?>
<div class="bg-red-100 border border-red-300 text-red-800 p-2 rounded mb-4">
    <?= session()->getFlashdata('error') ?>
</div>
<?php endif; ?>

<form action="<?= site_url('admin/validation/store') ?>" method="post" enctype="multipart/form-data" class="space-y-4">
    <div>
        <label class="block mb-1">Record Name (optional)</label>
        <input type="text" name="record_name" class="border rounded px-2 py-1 w-full">
    </div>

    <div>
        <label class="block mb-1">File</label>
        <input type="file" name="file" required class="border rounded px-2 py-1 w-full">
    </div>

    <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Add File</button>
</form>

<?= $this->endSection() ?>
