<?= $this->extend('admin/layout') ?>
<?= $this->section('content') ?>

<h2 class="text-2xl font-bold mb-4">Edit Validation</h2>

<form action="<?= site_url('admin/validation/update/'.$validation['id']) ?>" method="post" enctype="multipart/form-data" class="space-y-3">
    <div>
        <label>Record</label>
        <input type="text" name="record_name" value="<?= esc($validation['record_name']) ?>" class="border rounded px-2 py-1" required>
    </div>

    <div>
        <label>File</label>
        <input type="file" name="file" class="border rounded px-2 py-1">
        <?php if(!empty($validation['file'])): ?>
            <p class="text-sm mt-1">Current file: <a href="<?= base_url('uploads/'.$validation['file']) ?>" target="_blank"><?= esc($validation['file']) ?></a></p>
        <?php endif; ?>
    </div>

    <button type="submit" class="bg-yellow-500 text-white px-3 py-1 rounded">Update</button>
</form>

<?= $this->endSection() ?>
