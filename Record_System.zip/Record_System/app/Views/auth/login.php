<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>SKSU Scholarship Record System | Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="min-h-screen bg-cover bg-center flex items-center justify-center"
      style="background-image: url('<?= base_url('assets/images/sksu-bg.jpg') ?>');">

<div class="absolute inset-0 bg-black bg-opacity-40"></div>

<div class="relative z-10 w-full max-w-md bg-white bg-opacity-95 rounded-lg shadow-lg p-8">

    <!-- LOGO + TITLE -->
    <div class="text-center mb-6">
        <img src="<?= base_url('assets/images/sksu-logo.png') ?>" class="w-20 mx-auto mb-2">
        <h1 class="text-lg font-bold text-green-800">SULTAN KUDARAT STATE UNIVERSITY</h1>
        <p class="text-sm text-gray-600">Scholarship Record System</p>
    </div>

    <h2 class="text-center text-xl font-semibold mb-4">LOGIN</h2>

    <!-- FLASH MESSAGE -->
    <?php if(session()->getFlashdata('error')): ?>
        <div class="bg-red-100 text-red-700 p-2 mb-3 rounded">
            <?= session()->getFlashdata('error') ?>
        </div>
    <?php endif; ?>

    <?php if(session()->getFlashdata('success')): ?>
        <div class="bg-green-100 text-green-700 p-2 mb-3 rounded">
            <?= session()->getFlashdata('success') ?>
        </div>
    <?php endif; ?>

    <!-- ✅✅ FIXED LOGIN FORM -->
    <form action="<?= site_url('auth/process') ?>" method="post">

        <div class="mb-3">
            <label class="block text-sm">Email</label>
            <input type="email" name="email" required
                   class="w-full border rounded px-3 py-2">
        </div>

        <div class="mb-4">
            <label class="block text-sm">Password</label>
            <input type="password" name="password" required
                   class="w-full border rounded px-3 py-2">
        </div>

        <button type="submit" class="w-full bg-green-700 hover:bg-green-800 text-white py-2 rounded">
            LOGIN
        </button>

        <div class="flex justify-between mt-3 text-sm text-green-700">
            <a href="<?= site_url('auth/register') ?>">Create Account</a>
            <a href="#">Forgot Password?</a>
        </div>
    </form>
</div>

<!-- FOOTER -->
<div class="absolute bottom-0 w-full text-center bg-green-800 text-white py-2 text-sm">
    Email Support: sksu.scholarship@edu.ph
</div>

</body>
</html>
