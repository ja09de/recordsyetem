<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>SKSU Scholarship Management System | Register</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="min-h-screen bg-cover bg-center flex items-center justify-center"
      style="background-image: url('<?= base_url('assets/images/sksu-bg.jpg') ?>');">

<div class="absolute inset-0 bg-black bg-opacity-40"></div>

<div class="relative z-10 w-full max-w-md bg-white bg-opacity-95 rounded-lg shadow-lg p-8">

    <div class="text-center mb-6">
        <img src="<?= base_url('assets/images/sksu-logo.png') ?>" class="w-20 mx-auto mb-2">
        <h1 class="text-lg font-bold text-green-800">SULTAN KUDARAT STATE UNIVERSITY</h1>
        <p class="text-sm text-gray-600">Scholarship Record System</p>
    </div>

    <h2 class="text-center text-xl font-semibold mb-4">REGISTER</h2>

    <?php if(session()->getFlashdata('error')): ?>
        <div class="bg-red-100 text-red-700 p-2 mb-4 rounded text-sm">
            <?= session()->getFlashdata('error') ?>
        </div>
    <?php endif; ?>

    <?php if(session()->getFlashdata('success')): ?>
        <div class="bg-green-100 text-green-700 p-2 mb-4 rounded text-sm">
            <?= session()->getFlashdata('success') ?>
        </div>
    <?php endif; ?>

    <!-- ✅ FIXED FORM ACTION -->
    <form action="<?= site_url('auth/save') ?>" method="post">

        <div class="mb-3">
            <label class="block text-sm">Full Name</label>
            <input type="text" name="fullname" required
                   class="w-full border rounded px-3 py-2"
                   value="<?= old('fullname') ?>">
        </div>

        <div class="mb-3">
            <label class="block text-sm">Email</label>
            <input type="email" name="email" required
                   class="w-full border rounded px-3 py-2"
                   value="<?= old('email') ?>">
        </div>

        <div class="mb-3">
            <label class="block text-sm">Password</label>
            <input type="password" name="password" required
                   class="w-full border rounded px-3 py-2">
        </div>

        <div class="mb-4">
            <label class="block text-sm">Role</label>
            <select name="role" class="w-full border rounded px-3 py-2">
                <option value="user">User</option>
                <option value="admin">Admin</option>
            </select>
        </div>

        <button class="w-full bg-green-700 hover:bg-green-800 text-white py-2 rounded">
            REGISTER
        </button>

        <!-- ✅ FIXED LOGIN LINK (NO NESTED FORM) -->
        <div class="text-center mt-3 text-sm text-green-700">
            <a href="<?= site_url('auth/login') ?>">Already have an account? Login</a>
        </div>

    </form>
</div>

<div class="absolute bottom-0 w-full text-center bg-green-800 text-white py-2 text-sm">
    Email Support: sksu.scholarship@edu.ph
</div>

</body>
</html>
