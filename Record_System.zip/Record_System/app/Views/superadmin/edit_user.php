<?= $this->extend('superadmin/layout') ?>
<?= $this->section('content') ?>

<h2 class="text-2xl font-bold mb-4"><?= esc($title) ?></h2>

<form action="<?= site_url('superadmin/update_user/'.$user['id']) ?>" method="post" class="bg-white p-6 rounded shadow-md space-y-4 w-full md:w-1/2">
    <input type="text" name="fullname" value="<?= esc($user['fullname']) ?>" placeholder="Full Name" class="w-full border rounded px-3 py-2" required>
    <input type="email" name="email" value="<?= esc($user['email']) ?>" placeholder="Email" class="w-full border rounded px-3 py-2" required>
    <input type="password" name="password" placeholder="Password (leave blank if not changing)" class="w-full border rounded px-3 py-2">
    <select name="role" class="w-full border rounded px-3 py-2">
        <option value="admin" <?= $user['role']=='admin' ? 'selected' : '' ?>>Admin</option>
        <option value="user" <?= $user['role']=='user' ? 'selected' : '' ?>>User</option>
    </select>
    <label class="flex items-center gap-2">
        <input type="checkbox" name="status" value="1" <?= $user['status'] ? 'checked' : '' ?>>
        Active
    </label>
    <button type="submit" class="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600">Update User</button>
</form>

<?= $this->endSection() ?>
