<?= $this->extend('superadmin/salayout') ?>
<?= $this->section('content') ?>

<h2 class="text-2xl font-bold mb-4"><?= esc($title) ?></h2>

<a href="<?= site_url('superadmin/users/create') ?>" 
   class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 mb-4 inline-block">➕ Add User</a>

<div class="overflow-x-auto bg-white shadow rounded p-4">
    <table class="min-w-full text-sm">
        <thead class="bg-teal-500 text-white">
            <tr>
                <th class="px-4 py-2 text-left">ID</th>
                <th class="px-4 py-2 text-left">Name</th>
                <th class="px-4 py-2 text-left">Email</th>
                <th class="px-4 py-2 text-left">Role</th>
                <th class="px-4 py-2 text-left">Status</th>
                <th class="px-4 py-2 text-center">Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php if(!empty($users)): foreach($users as $user): ?>
            <tr class="border-b">
                <td class="px-4 py-2"><?= $user['id'] ?></td>
                <td class="px-4 py-2"><?= esc($user['fullname']) ?></td>
                <td class="px-4 py-2"><?= esc($user['email']) ?></td>
                <td class="px-4 py-2"><?= strtoupper($user['role']) ?></td>
                <td class="px-4 py-2"><?= $user['status'] ? 'Active' : 'Inactive' ?></td>
                <td class="px-4 py-2 flex gap-2 justify-center">
                    <a href="<?= site_url('superadmin/users/edit/'.$user['id']) ?>" 
                       class="bg-yellow-500 px-2 py-1 rounded text-white">✏ Edit</a>
                    <a href="<?= site_url('superadmin/users/delete/'.$user['id']) ?>" 
                       onclick="return confirm('Delete this user?')" 
                       class="bg-red-500 px-2 py-1 rounded text-white">🗑 Delete</a>
                </td>
            </tr>
        <?php endforeach; else: ?>
            <tr>
                <td colspan="6" class="text-center py-4 text-gray-500">No users found.</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?= $this->endSection() ?>
