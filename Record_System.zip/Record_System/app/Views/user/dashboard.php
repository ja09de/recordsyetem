<?= $this->extend('admin/layout') ?>
<?= $this->section('content') ?>

<h2 class="text-2xl font-bold mb-4"><?= esc($title) ?></h2>

<!-- General Totals -->
<div class="mb-6 flex gap-6">
    <div class="bg-white p-4 shadow rounded w-48 text-center">
        <h3 class="font-bold">Total IN</h3>
        <p class="text-2xl font-semibold text-green-600"><?= $total_in ?? 0 ?></p>
    </div>
    <div class="bg-white p-4 shadow rounded w-48 text-center">
        <h3 class="font-bold">Total OUT</h3>
        <p class="text-2xl font-semibold text-red-600"><?= $total_out ?? 0 ?></p>
    </div>
</div>

<!-- Cards per module -->
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
    <div class="bg-white p-4 shadow rounded">
        <h3 class="font-bold">Validation</h3>
        <p>IN: <?= $validation_in ?? 0 ?></p>
        <p>OUT: <?= $validation_out ?? 0 ?></p>
    </div>
    <div class="bg-white p-4 shadow rounded">
        <h3 class="font-bold">Liquidation</h3>
        <p>IN: <?= $liquidation_in ?? 0 ?></p>
        <p>OUT: <?= $liquidation_out ?? 0 ?></p>
    </div>
    <div class="bg-white p-4 shadow rounded">
        <h3 class="font-bold">Disbursement</h3>
        <p>IN: <?= $disbursement_in ?? 0 ?></p>
        <p>OUT: <?= $disbursement_out ?? 0 ?></p>
    </div>
    <div class="bg-white p-4 shadow rounded">
        <h3 class="font-bold">Billing</h3>
        <p>IN: <?= $billing_in ?? 0 ?></p>
        <p>OUT: <?= $billing_out ?? 0 ?></p>
    </div>
</div>

<!-- Charts per module -->
<div class="grid grid-cols-1 md:grid-cols-2 gap-6">
    <?php $chartData = [
        ['id' => 'validationChart', 'data' => $validation_chart ?? ['labels'=>[], 'totals'=>[]], 'label' => 'Validation'],
        ['id' => 'liquidationChart', 'data' => $liquidation_chart ?? ['labels'=>[], 'totals'=>[]], 'label' => 'Liquidation'],
        ['id' => 'disbursementChart', 'data' => $disbursement_chart ?? ['labels'=>[], 'totals'=>[]], 'label' => 'Disbursement'],
        ['id' => 'billingChart', 'data' => $billing_chart ?? ['labels'=>[], 'totals'=>[]], 'label' => 'Billing'],
    ]; ?>

    <?php foreach($chartData as $c): ?>
    <div class="bg-white p-4 shadow rounded">
        <h3 class="font-bold mb-2"><?= esc($c['label']) ?> Trend</h3>
        <canvas id="<?= esc($c['id']) ?>"></canvas>
    </div>
    <?php endforeach; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const charts = <?= json_encode($chartData) ?>;

charts.forEach(c => {
    new Chart(document.getElementById(c.id), {
        type: 'line',
        data: {
            labels: c.data.labels,
            datasets: [{
                label: c.label + ' per Day',
                data: c.data.totals,
                borderColor: 'rgba(34, 197, 94, 1)',
                backgroundColor: 'rgba(34, 197, 94, 0.2)',
                fill: true,
                tension: 0.3
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { display: true },
                tooltip: { mode: 'index', intersect: false }
            },
            scales: {
                x: { title: { display: true, text: 'Date' } },
                y: { title: { display: true, text: 'Total Files' }, beginAtZero: true }
            }
        }
    });
});
</script>

<?= $this->endSection() ?>
