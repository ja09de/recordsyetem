<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= esc($title ?? 'User Dashboard') ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen flex">

    <!-- SIDEBAR -->
    <aside class="w-64 bg-teal-600 text-white flex flex-col">

        <!-- PROFILE SECTION -->
        <div class="p-6 border-b border-teal-500 text-center">
            <?php if(session()->get('profile_pic')): ?>
                <img src="<?= base_url('writable/uploads/profile/' . session()->get('profile_pic')) ?>" 
                     alt="Profile Picture" 
                     class="w-20 h-20 rounded-full mx-auto mb-2 border-2 border-white">
            <?php else: ?>
                <div class="w-20 h-20 rounded-full mx-auto mb-2 bg-gray-300 flex items-center justify-center text-gray-600 font-bold">
                    <?= strtoupper(substr(session()->get('name'), 0, 2)) ?>
                </div>
            <?php endif; ?>

            <h2 class="font-bold text-lg"><?= esc(session()->get('name')) ?></h2>
            <p class="text-sm"><?= esc(session()->get('role')) ?></p>
        </div>

        <!-- NAVIGATION -->
        <nav class="flex-1 p-4 space-y-2">
            <a href="<?= site_url('user/dashboard') ?>" class="block px-4 py-2 rounded hover:bg-teal-500">🏠 Dashboard</a>
            <a href="<?= site_url('user/validation_list') ?>" class="block px-4 py-2 rounded hover:bg-teal-500">✅ Validation</a>
            <a href="<?= site_url('user/liquidation_list') ?>" class="block px-4 py-2 rounded hover:bg-teal-500">🧾 Liquidation</a>
            <a href="<?= site_url('user/disbursement_list') ?>" class="block px-4 py-2 rounded hover:bg-teal-500">💸 Disbursement</a>
            <a href="<?= site_url('user/billing_list') ?>" class="block px-4 py-2 rounded hover:bg-teal-500">🗂 Billing</a>
            <a href="<?= site_url('user/profile') ?>" class="block px-4 py-2 rounded hover:bg-teal-500">👤 Profile</a>
            <a href="<?= site_url('auth/logout') ?>" class="block px-4 py-2 rounded hover:bg-red-500">🚪 Logout</a>
        </nav>
    </aside>

    <!-- MAIN CONTENT -->
    <main class="flex-1 p-8 overflow-auto">
        <div class="max-w-7xl mx-auto">
            <?= $this->renderSection('content') ?>
        </div>
    </main>

</body>
</html>
