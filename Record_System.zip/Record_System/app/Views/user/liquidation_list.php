<?= $this->extend('admin/layout') ?>
<?= $this->section('content') ?>

<h2 class="text-2xl font-bold mb-4">Validation Files</h2>

<!-- Add & Search -->
<div class="flex items-center justify-between mb-4">
    <a href="<?= site_url('admin/validation_create') ?>" class="bg-blue-500 text-white px-4 py-2 rounded-lg font-semibold hover:bg-blue-600 transition">+ Add File</a>
    <div class="relative w-1/3">
        <input type="text" id="tableSearch" placeholder="Search..." class="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-400">
        <span class="absolute left-3 top-2.5 text-gray-400">🔍</span>
    </div>
</div>

<?php if(session()->getFlashdata('success')): ?>
<div class="bg-green-100 border border-green-300 text-green-800 p-3 rounded mb-4">
    <?= session()->getFlashdata('success') ?>
</div>
<?php endif; ?>

<div class="overflow-x-auto">
<table class="min-w-full bg-white shadow-lg rounded-lg overflow-hidden">
    <thead class="bg-teal-500 text-white text-sm uppercase tracking-wide">
        <tr>
            <th class="px-4 py-3 text-left">ID</th>
            <th class="px-4 py-3 text-left">Record</th>
            <th class="px-4 py-3 text-left">File</th>
            <th class="px-4 py-3 text-left">Status</th>
            <th class="px-4 py-3 text-left">Uploaded</th>
            <th class="px-4 py-3 text-center">Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php if(!empty($files)): ?>
        <?php foreach($files as $file): ?>
        <tr class="border-b hover:bg-gray-50 transition">
            <td class="px-4 py-3"><?= $file['id'] ?></td>
            <td class="px-4 py-3"><?= esc($file['record_name']) ?></td>
            <td class="px-4 py-3">
                <?php if(!empty($file['file'])): ?>
                    <a href="<?= site_url('user/validation/view/'.$file['file']) ?>" target="_blank" class="inline-flex items-center gap-1 bg-blue-500 hover:bg-blue-600 text-white px-3 py-1 rounded-full text-xs font-semibold transition">
                        📄 View
                    </a>
                <?php else: ?>
                    <span class="text-gray-500 text-sm">No File</span>
                <?php endif; ?>
            </td>
            <td class="px-4 py-3">
                <span class="px-3 py-1 rounded-full text-xs font-bold <?= $file['in_status'] ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700' ?>">
                    <?= $file['in_status'] ? 'IN' : 'OUT' ?>
                </span>
            </td>
            <td class="px-4 py-3"><?= esc($file['uploaded_at']) ?></td>
            <td class="px-4 py-3 flex justify-center gap-2 flex-wrap">
                <a href="<?= site_url('admin/validation/toggleInOut/'.$file['id']) ?>" class="px-3 py-1 rounded-full text-xs font-bold tracking-wide <?= $file['in_status'] ? 'bg-red-500 hover:bg-red-600' : 'bg-green-500 hover:bg-green-600' ?> text-white transition">
                    <?= $file['in_status'] ? 'MARK OUT' : 'MARK IN' ?>
                </a>
                <a href="<?= site_url('admin/validation/edit/'.$file['id']) ?>" class="px-3 py-1 rounded-full text-xs font-semibold bg-blue-500 hover:bg-blue-600 text-white transition">✏ Edit</a>
                <a href="<?= site_url('admin/validation/delete/'.$file['id']) ?>" onclick="return confirm('Delete this file?')" class="px-3 py-1 rounded-full text-xs font-semibold bg-red-500 hover:bg-red-600 text-white transition">🗑 Delete</a>
            </td>
        </tr>
        <?php endforeach; ?>
    <?php else: ?>
        <tr>
            <td colspan="6" class="text-center px-4 py-6 text-gray-500">No validation files found.</td>
        </tr>
    <?php endif; ?>
    </tbody>
</table>
</div>

<script>
document.getElementById('tableSearch').addEventListener('keyup', function () {
    let value = this.value.toLowerCase();
    document.querySelectorAll('tbody tr').forEach(row => {
        row.style.display = row.textContent.toLowerCase().includes(value) ? '' : 'none';
    });
});
</script>

<?= $this->endSection() ?>
