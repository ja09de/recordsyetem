<?= $this->extend('user/layout') ?>
<?= $this->section('content') ?>

<h2 class="text-2xl font-bold mb-4"><?= esc($title) ?></h2>

<?php if(session()->getFlashdata('error')): ?>
<div class="bg-red-100 border border-red-300 text-red-800 p-2 rounded mb-4">
    <?= session()->getFlashdata('error') ?>
</div>
<?php endif; ?>

<form action="<?= site_url('user/update/'.$file['id']) ?>" method="post" enctype="multipart/form-data" class="space-y-4">

    <!-- Record Name -->
    <div>
        <label class="block mb-1">Record Name</label>
        <input type="text" name="record_name" class="border rounded px-2 py-1 w-full"
               value="<?= esc($file['record_name']) ?>" required>
    </div>

    <!-- File Upload -->
    <div>
        <label class="block mb-1">Replace File (optional)</label>
        <input type="file" name="file" class="border rounded px-2 py-1 w-full">
        <?php if(!empty($file['file'])): ?>
            <small class="text-gray-500">Current file: <?= esc($file['file']) ?></small>
        <?php endif; ?>
    </div>

    <button type="submit" class="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600">
        Update File
    </button>
</form>

<?= $this->endSection() ?>
