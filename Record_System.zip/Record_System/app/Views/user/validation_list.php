<?= $this->extend('user/layout') ?>
<?= $this->section('content') ?>

<h2 class="text-2xl font-bold mb-4">Validation Files</h2>

<!-- TOP BAR -->
<div class="flex items-center justify-between mb-4">
    <div class="text-gray-600 text-sm">
        Upload and manage your validation files
    </div>

    <div class="flex gap-3 items-center">
        <!-- ADD FILE BUTTON -->
        <a href="<?= site_url('user/validation_add') ?>" 
           class="bg-green-700 hover:bg-green-800 text-white px-4 py-2 rounded shadow text-sm">
           ➕ Add File
        </a>

        <!-- SEARCH -->
        <div class="relative w-64">
            <input type="text" id="tableSearch"
                   placeholder="Search record, file, status..."
                   class="w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-teal-400">
            <span class="absolute left-3 top-2.5 text-gray-400">🔍</span>
        </div>
    </div>
</div>

<!-- SUCCESS / ERROR MESSAGES -->
<?php if(session()->getFlashdata('success')): ?>
<div class="bg-green-100 border border-green-300 text-green-800 p-3 rounded mb-4">
    <?= session()->getFlashdata('success') ?>
</div>
<?php endif; ?>

<?php if(session()->getFlashdata('error')): ?>
<div class="bg-red-100 border border-red-300 text-red-800 p-3 rounded mb-4">
    <?= session()->getFlashdata('error') ?>
</div>
<?php endif; ?>

<!-- TABLE -->
<div class="overflow-x-auto">
<table class="min-w-full bg-white shadow-lg rounded-lg">
    <thead class="bg-teal-500 text-white text-sm uppercase">
        <tr>
            <th class="px-4 py-3 text-left">ID</th>
            <th class="px-4 py-3 text-left">Record</th>
            <th class="px-4 py-3 text-left">File</th>
            <th class="px-4 py-3 text-left">Status</th>
            <th class="px-4 py-3 text-left">Uploaded</th>
            <th class="px-4 py-3 text-center">Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php if(!empty($files)): ?>
        <?php foreach($files as $file): ?>
        <tr class="border-b hover:bg-gray-50">
            <td class="px-4 py-3"><?= $file['id'] ?></td>
            <td class="px-4 py-3 font-medium"><?= esc($file['record_name']) ?></td>

            <!-- FILE -->
            <td class="px-4 py-3">
                <?php if(!empty($file['file'])): ?>
                    <a href="<?= base_url('uploads/'.$file['file']) ?>" target="_blank"
                       class="inline-flex items-center gap-1 bg-blue-500 hover:bg-blue-600
                              text-white px-3 py-1 rounded-full text-xs font-semibold transition">
                        📄 View
                    </a>
                <?php else: ?>
                    <span class="text-gray-500 text-sm">No File</span>
                <?php endif; ?>
            </td>

            <!-- STATUS -->
            <td class="px-4 py-3">
                <span class="px-3 py-1 rounded-full text-xs font-bold
                      <?= $file['in_status'] ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700' ?>">
                    <?= $file['in_status'] ? 'IN' : 'OUT' ?>
                </span>
            </td>

            <td class="px-4 py-3 text-sm"><?= esc($file['uploaded_at']) ?></td>

            <!-- USER ACTIONS -->
            <td class="px-4 py-3 flex justify-center gap-2 flex-wrap">
                <!-- MARK IN/OUT -->
                <a href="<?= site_url('user/toggleInOut/'.$file['id']) ?>"
                   class="px-3 py-1 rounded-full text-xs font-bold
                   <?= $file['in_status'] ? 'bg-red-500 hover:bg-red-600' : 'bg-green-500 hover:bg-green-600' ?>
                   text-white transition">
                    <?= $file['in_status'] ? 'MARK OUT' : 'MARK IN' ?>
                </a>

                <!-- EDIT -->
                <a href="<?= site_url('user/edit/'.$file['id']) ?>"
                   class="bg-yellow-500 hover:bg-yellow-600 text-white px-3 py-1 rounded-full text-xs">
                   ✏ Edit
                </a>

                <!-- DELETE -->
                <a href="<?= site_url('user/delete/'.$file['id']) ?>"
                   onclick="return confirm('Delete this file?')"
                   class="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded-full text-xs">
                   🗑 Delete
                </a>
            </td>
        </tr>
        <?php endforeach; ?>
    <?php else: ?>
        <tr>
            <td colspan="6" class="text-center py-6 text-gray-500">
                No validation files found.
            </td>
        </tr>
    <?php endif; ?>
    </tbody>
</table>
</div>

<!-- SEARCH SCRIPT -->
<script>
document.getElementById('tableSearch').addEventListener('keyup', function () {
    const value = this.value.toLowerCase();
    document.querySelectorAll('tbody tr').forEach(row => {
        row.style.display = row.textContent.toLowerCase().includes(value) ? '' : 'none';
    });
});
</script>

<?= $this->endSection() ?>
