-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 17, 2025 at 03:51 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `record_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_logs`
--

CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `module` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `applications`
--

CREATE TABLE `applications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `scholarship_id` int(11) NOT NULL,
  `status` varchar(50) DEFAULT 'Pending',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `file` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `billing`
--

CREATE TABLE `billing` (
  `id` int(11) NOT NULL,
  `record_name` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` varchar(20) DEFAULT 'Unpaid',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `in_status` tinyint(1) DEFAULT 1,
  `uploaded_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `billing`
--

INSERT INTO `billing` (`id`, `record_name`, `file`, `user_id`, `amount`, `status`, `created_at`, `updated_at`, `in_status`, `uploaded_at`) VALUES
(2, 'for billing', '1764778962_2cf47fa7db56e3b45e3a.docx', 0, 0.00, 'Unpaid', '2025-12-04 00:22:42', '2025-12-17 13:19:22', 0, '2025-12-03 16:22:42'),
(3, 'Jade', '1765342318_f138c8c386b36846917b.pdf', 0, 0.00, 'Unpaid', '2025-12-10 12:51:58', '2025-12-10 12:51:58', 0, '2025-12-10 04:51:58'),
(4, 'Jonalyn', '1765387932_b6358cdb1435dca84e77.pdf', 0, 0.00, 'Unpaid', '2025-12-11 01:32:12', '2025-12-17 13:19:20', 0, '2025-12-10 17:32:12'),
(5, 'John', '1765948900_8043dd2854ea8d44f279.pdf', 0, 0.00, 'Unpaid', '2025-12-17 13:21:40', '2025-12-17 13:22:00', 1, '2025-12-17 05:21:40');

-- --------------------------------------------------------

--
-- Table structure for table `billings`
--

CREATE TABLE `billings` (
  `id` int(11) NOT NULL,
  `record_name` varchar(255) DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `in_status` tinyint(1) DEFAULT 0,
  `uploaded_at` datetime DEFAULT current_timestamp(),
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `disbursements`
--

CREATE TABLE `disbursements` (
  `id` int(11) NOT NULL,
  `record_name` varchar(255) NOT NULL,
  `scholar_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `semester` varchar(50) DEFAULT NULL,
  `amount` decimal(12,2) DEFAULT NULL,
  `purpose` text DEFAULT NULL,
  `status` enum('Pending','For Review','Approved','Rejected','Released') DEFAULT 'Pending',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  `in_status` tinyint(1) NOT NULL DEFAULT 1,
  `uploaded_at` datetime NOT NULL DEFAULT current_timestamp(),
  `file` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `disbursements`
--

INSERT INTO `disbursements` (`id`, `record_name`, `scholar_id`, `user_id`, `semester`, `amount`, `purpose`, `status`, `created_at`, `updated_at`, `in_status`, `uploaded_at`, `file`) VALUES
(16, 'Jade', NULL, NULL, NULL, NULL, NULL, 'Pending', '2025-12-10 13:53:36', '2025-12-10 13:53:36', 1, '2025-12-10 05:53:36', '1765346016_3d6fa789340e9bbb8d8b.pdf'),
(17, 'Jonalyn ', NULL, NULL, NULL, NULL, NULL, 'Pending', '2025-12-10 13:58:02', '2025-12-10 13:58:02', 1, '2025-12-10 05:58:02', '1765346282_8fdb7dd0eca203a2e082.pdf'),
(18, 'Jade', NULL, NULL, NULL, NULL, NULL, 'Pending', '2025-12-10 14:01:12', '2025-12-10 14:01:12', 1, '2025-12-10 06:01:12', '1765346472_e3845d7a9112bb4a5602.pdf'),
(19, 'Jon', NULL, NULL, NULL, NULL, NULL, 'Pending', '2025-12-10 14:03:38', '2025-12-10 14:03:38', 1, '2025-12-10 06:03:38', '1765346618_4bf8f5aa33c7addc8e46.pdf'),
(20, 'hahahah', NULL, NULL, NULL, NULL, NULL, 'Pending', '2025-12-11 00:33:26', '2025-12-11 00:33:26', 1, '2025-12-10 16:33:26', '1765384406_97bcacbb3000ad0e71a2.pdf'),
(21, 'jADE', NULL, NULL, NULL, NULL, NULL, 'Pending', '2025-12-11 01:00:22', '2025-12-11 01:00:22', 0, '2025-12-10 17:00:22', '1765386022_6621f84b7e447d717136.pdf'),
(22, 'Jade', NULL, NULL, NULL, NULL, NULL, 'Pending', '2025-12-11 01:11:16', '2025-12-11 01:11:16', 0, '2025-12-10 17:11:16', '1765386676_fc0256d57f17b5da9010.pdf'),
(23, 'jonalyn Sialza', NULL, NULL, NULL, NULL, NULL, 'Pending', '2025-12-11 01:27:54', '2025-12-11 01:27:54', 0, '2025-12-10 17:27:54', '1765387674_a4e2f7ab0e9a032989ac.pdf'),
(24, 'Gwen', NULL, NULL, NULL, NULL, NULL, 'Pending', '2025-12-17 13:20:53', '2025-12-17 13:20:53', 1, '2025-12-17 05:20:53', '1765948853_a25dcf83f99c516d20e2.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `documents`
--

CREATE TABLE `documents` (
  `id` int(11) NOT NULL,
  `module` enum('scholar','disbursement','liquidation','billing') DEFAULT NULL,
  `reference_id` int(11) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `uploaded_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `liquidations`
--

CREATE TABLE `liquidations` (
  `id` int(11) NOT NULL,
  `record_name` varchar(255) NOT NULL,
  `file` varchar(255) DEFAULT NULL,
  `disbursement_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `total_amount` decimal(12,2) DEFAULT NULL,
  `expenses` decimal(12,2) DEFAULT NULL,
  `remaining` decimal(12,2) DEFAULT NULL,
  `status` enum('Pending','For Review','For Correction','Approved','Liquidated') DEFAULT 'Pending',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  `in_status` tinyint(1) NOT NULL DEFAULT 1,
  `uploaded_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `liquidations`
--

INSERT INTO `liquidations` (`id`, `record_name`, `file`, `disbursement_id`, `user_id`, `total_amount`, `expenses`, `remaining`, `status`, `created_at`, `updated_at`, `in_status`, `uploaded_at`) VALUES
(4, 'jhawjq', '1765386944_d011e944a9f4be21566a.pdf', NULL, NULL, NULL, NULL, NULL, 'Pending', '2025-12-10 17:15:44', '2025-12-10 17:32:48', 1, '2025-12-10 17:15:44'),
(5, 'Angel', '1765948872_7ed940c103fbc6144330.pdf', NULL, NULL, NULL, NULL, NULL, 'Pending', '2025-12-17 05:21:12', '2025-12-17 05:21:52', 1, '2025-12-17 05:21:12');

-- --------------------------------------------------------

--
-- Table structure for table `scholars`
--

CREATE TABLE `scholars` (
  `id` int(11) NOT NULL,
  `scholar_no` varchar(50) DEFAULT NULL,
  `fullname` varchar(150) DEFAULT NULL,
  `program` varchar(100) DEFAULT NULL,
  `year_level` varchar(50) DEFAULT NULL,
  `school` varchar(150) DEFAULT NULL,
  `status` enum('active','archived') DEFAULT 'active',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','user') DEFAULT 'user',
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `email`, `password`, `role`, `status`, `created_at`, `updated_at`) VALUES
(3, 'Jade Tanquerido', 'tanqueridojade@gmail.com', '$2y$10$C8KS02Vvv4g6nZz8CtbrFedtR9uLCSjRYHj9sfcxQdyEThkkmFPgG', 'admin', 'active', '2025-11-30 13:48:08', '2025-11-30 13:48:08'),
(6, 'Sialza Jonalyn', 'sialzajonalyn@gmail.com', '$2y$10$VXyKO8vL87vpIVUwNRJbee7W3ufGU0JsFthY1sQqb08rF/MuLm9Vy', 'admin', 'active', '2025-12-02 12:59:37', '2025-12-02 12:59:37'),
(18, 'Rashell', 'rashell@gmail.com', '$2y$10$8SXTELCnuhgLCzuVlOElcOafJxNMZsT4KPNIUJe7i0TCfp0X6ipIO', 'user', 'active', '2025-12-17 09:19:04', '2025-12-17 09:19:04');

-- --------------------------------------------------------

--
-- Table structure for table `validations`
--

CREATE TABLE `validations` (
  `id` int(11) NOT NULL,
  `record_name` varchar(255) NOT NULL,
  `file` varchar(255) DEFAULT NULL,
  `module` enum('disbursement','liquidation','billing') DEFAULT NULL,
  `reference_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Pending',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `uploaded_by` varchar(100) DEFAULT NULL,
  `uploaded_at` datetime DEFAULT current_timestamp(),
  `approved_by` varchar(255) DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `in_status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `validations`
--

INSERT INTO `validations` (`id`, `record_name`, `file`, `module`, `reference_id`, `user_id`, `remarks`, `status`, `created_at`, `updated_at`, `uploaded_by`, `uploaded_at`, `approved_by`, `approved_at`, `in_status`) VALUES
(8, 'Auto-Generated Record', NULL, NULL, NULL, NULL, NULL, 'Validated', '2025-12-02 17:48:05', '2025-12-02 17:49:27', NULL, '2025-12-02 17:48:05', NULL, NULL, 1),
(11, 'Auto-Generated Record', NULL, NULL, NULL, NULL, NULL, 'Pending', '2025-12-02 18:24:58', '2025-12-02 18:24:58', NULL, '2025-12-02 18:24:58', NULL, NULL, 1),
(12, 'For validation', NULL, NULL, NULL, NULL, NULL, 'Pending', NULL, NULL, 'Staff', '2025-12-03 05:40:29', NULL, NULL, 1),
(13, '', NULL, NULL, NULL, NULL, NULL, 'Pending', NULL, NULL, 'Staff', '2025-12-03 16:37:02', NULL, NULL, 1),
(14, 'Sialza Jonalyn, B.', NULL, NULL, NULL, NULL, NULL, 'Pending', NULL, NULL, 'Staff', '2025-12-07 13:37:24', NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `validation_files`
--

CREATE TABLE `validation_files` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `record_name` varchar(150) NOT NULL,
  `file` varchar(255) DEFAULT NULL,
  `in_status` tinyint(1) DEFAULT 1,
  `uploaded_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `validation_files`
--

INSERT INTO `validation_files` (`id`, `user_id`, `record_name`, `file`, `in_status`, `uploaded_at`) VALUES
(40, 0, 'Rashell', '1765971955_2d5a76fcdb5f6e941fab.pdf', 0, '2025-12-17 11:45:55'),
(41, 0, 'Jade ', '1765972610_05e7c925323a31d91834.pdf', 1, '2025-12-17 11:56:50'),
(42, 0, 'JONALYN', '1765975533_343bede8337bd6971316.pdf', 1, '2025-12-17 12:45:33'),
(43, 0, 'JJ', '1765975893_fd1140c1b9d70e4490c9.pdf', 1, '2025-12-17 12:51:33'),
(44, 0, 'Queen Angel B. Dolor', '1765976358_c3fa641f6c8d05e999e0.pdf', 1, '2025-12-17 12:59:18'),
(45, 0, 'jdfgh', '1765978133_62ff43188de36260825c.pdf', 1, '2025-12-17 13:28:53'),
(46, 0, 'For validation', '1765978969_2932094681cccb405761.pdf', 1, '2025-12-17 13:42:49'),
(47, 0, 'jade', '1765979455_622349cd6e11449cfbc0.pdf', 1, '2025-12-17 13:50:55'),
(48, 0, 'jju', '1765980443_bb225eb9b237337dbf42.pdf', 1, '2025-12-17 14:07:23'),
(49, 0, 'ghsgj', '1765981713_02b5659c4db35d5e41ad.pdf', 1, '2025-12-17 14:28:33'),
(50, 0, 'sfjhdlfkjds', '1765982171_1beac6ae0d170cde4a53.pdf', 1, '2025-12-17 14:36:11'),
(51, 0, 'hjdjsaf', '1765982394_cad3bf9a20147bfae9ef.pdf', 1, '2025-12-17 14:39:54'),
(52, 0, 'for billing', '1765982579_c4e18bd9da8eaef38767.pdf', 1, '2025-12-17 14:42:59'),
(53, 0, 'klj\'k,', '1765983578_b42d8161c4c942b70557.pdf', 1, '2025-12-17 14:59:38'),
(54, 0, 'Jade', '1765983901_59802bec894322b2d28b.pdf', 1, '2025-12-17 15:05:01'),
(55, 0, 'nkn;km', '1765984281_2c92995e458b7b4522c3.pdf', 1, '2025-12-17 15:11:21');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `applications`
--
ALTER TABLE `applications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `billing`
--
ALTER TABLE `billing`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `billings`
--
ALTER TABLE `billings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `disbursements`
--
ALTER TABLE `disbursements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `scholar_id` (`scholar_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `documents`
--
ALTER TABLE `documents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uploaded_by` (`uploaded_by`);

--
-- Indexes for table `liquidations`
--
ALTER TABLE `liquidations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `disbursement_id` (`disbursement_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `scholars`
--
ALTER TABLE `scholars`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `validations`
--
ALTER TABLE `validations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `validation_files`
--
ALTER TABLE `validation_files`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_logs`
--
ALTER TABLE `activity_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `applications`
--
ALTER TABLE `applications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `billing`
--
ALTER TABLE `billing`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `billings`
--
ALTER TABLE `billings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `disbursements`
--
ALTER TABLE `disbursements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `documents`
--
ALTER TABLE `documents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `liquidations`
--
ALTER TABLE `liquidations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `scholars`
--
ALTER TABLE `scholars`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `validations`
--
ALTER TABLE `validations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `validation_files`
--
ALTER TABLE `validation_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD CONSTRAINT `activity_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `disbursements`
--
ALTER TABLE `disbursements`
  ADD CONSTRAINT `disbursements_ibfk_1` FOREIGN KEY (`scholar_id`) REFERENCES `scholars` (`id`),
  ADD CONSTRAINT `disbursements_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `documents`
--
ALTER TABLE `documents`
  ADD CONSTRAINT `documents_ibfk_1` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `liquidations`
--
ALTER TABLE `liquidations`
  ADD CONSTRAINT `liquidations_ibfk_1` FOREIGN KEY (`disbursement_id`) REFERENCES `disbursements` (`id`),
  ADD CONSTRAINT `liquidations_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `validations`
--
ALTER TABLE `validations`
  ADD CONSTRAINT `validations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
